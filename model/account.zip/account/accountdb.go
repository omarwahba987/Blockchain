package account

import (
	"encoding/json"
	"fmt"
	"log"
	"strconv"
	"strings"
	"time"

	errorpk "../errorpk" //  write an error on the json file
	globalPkg "../globalPkg"
	"../validator"

	"github.com/syndtr/goleveldb/leveldb"
)

//------------------------------------------------------------------------------------------------------------
//struct for object to be saved in db
//------------------------------------------------------------------------------------------------------------
type AccountStruct struct {
	AccountName                string
	AccountInitialUserName     string
	AccountInitialPassword     string
	AccountAuthenticationType  string
	AccountAuthenticationValue string
	AccountIndex               string
	AccountPassword            string
	AccountEmail               string
	AccountPhoneNumber         string
	AccountAddress             string
	AccountPublicKey           string
	AccountPrivateKey          string
	AccountStatus              bool
	AccountRole                string
	AccountLastUpdatedTime     time.Time
	AccountDeactivatedReason   string
	AccountBalance             string
	BlocksLst                  []string
	SessionID                  string
	AccountTokenID             string
}

//------------------------------------------------------------------------------------------------------------
//struct for object reated to AcountStruct object
//------------------------------------------------------------------------------------------------------------
type AccountNameStruct struct {
	AccountName  string
	AccountIndex string
}

//------------------------------------------------------------------------------------------------------------
//struct for object reated to AcountStruct object
//------------------------------------------------------------------------------------------------------------
type AccountPublicKeyStruct struct {
	AccountPublicKey string
	AccountIndex     string
}

//------------------------------------------------------------------------------------------------------------
//struct for object reated to AcountStruct object
//------------------------------------------------------------------------------------------------------------
type AccountEmailStruct struct {
	AccountEmail string
	AccountIndex string
}

//------------------------------------------------------------------------------------------------------------
//struct for object reated to AcountStruct object
//------------------------------------------------------------------------------------------------------------
type AccountPhoneNumberStruct struct {
	AccountPhoneNumber string
	AccountIndex       string
}

//------------------------------------------------------------------------------------------------------------
//struct for object reated to AcountStruct object
//------------------------------------------------------------------------------------------------------------
type AccountLastUpdatedTimestruct struct {
	AccountLastUpdatedTime time.Time
	AccountIndex           string
}

//var DBpath = "Database/AccountStruct"
var DB *leveldb.DB
var DBEmail *leveldb.DB
var DBName *leveldb.DB
var DBPublicKey *leveldb.DB
var DBPhoneNo *leveldb.DB
var DBLastUpdateTime *leveldb.DB
var Open = false

//------------------------------------------------------------------------------------------------------------
// create or open db if exist
//------------------------------------------------------------------------------------------------------------
func Opendatabase() bool {
	if !Open {
		Open = true
		dbpath := "Database/AccountStruct"
		var err error
		DB, err = leveldb.OpenFile(dbpath, nil)
		if err != nil {

			errorpk.AddError("opendatabase AccountStruct package", "can't open the database", "critical error")
			return false
		}
		dbpath = "Database/TempAccount/AccountEmailStruct"
		DBEmail, _ = leveldb.OpenFile(dbpath, nil)
		dbpath = "Database/TempAccount/AccountLastUpdatedTimestruct"
		DBLastUpdateTime, _ = leveldb.OpenFile(dbpath, nil)
		dbpath = "Database/TempAccount/AccountNameStruct"
		DBName, _ = leveldb.OpenFile(dbpath, nil)
		dbpath = "Database/TempAccount/AccountPhoneNumberStruct"
		DBPhoneNo, _ = leveldb.OpenFile(dbpath, nil)
		dbpath = "Database/TempAccount/AccountPublicKeyStruct"
		DBPublicKey, _ = leveldb.OpenFile(dbpath, nil)
		return true

	}
	return true

}

//-------------------------------------------------------------------------------------------------------------
// insert AccountStruct
//-------------------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------------------
// create or open db if exist for ancidate use
//------------------------------------------------------------------------------------------------------------
// this is function to create a connection to private database that is created by defauilt in your code
// dont use global vars in the path instead you can use Opendatabase()
// func OpendatabaseCandidate(path string) (bool, *leveldb.DB) {
// 	var err error
// 	dbobj, err := leveldb.OpenFile(path, nil)
// 	if err != nil {
// 		errorpk.AddError("opencandidatedatabase package", "can't open the database on this path : "+path, "critical error")
// 		return false, nil
// 	}
// 	return true, dbobj
// }

//-------------------------------------------------------------------------------------------------------------
// insert AccountNameStruct
//-------------------------------------------------------------------------------------------------------------
func accountNameCreate(data AccountNameStruct) bool {
	var err error
	// open, dbobj := OpendatabaseCandidate("Database/TempAccount/AccountNameStruct")
	// if !open {
	// 	errorpk.AddError("opendatabase AccountNameStruct package", "can't open the database", "critical error")
	// 	return false
	// }
	d, convert := globalPkg.ConvetToByte(data, "accountNameCreate account package")
	if !convert {
		return false
	}
	err = DBName.Put([]byte(data.AccountName), d, nil)
	if err != nil {
		errorpk.AddError("AccountNameStructCreate  AccountNameStruct package", "can't create AccountNameStruct", "runtime error")
		return false
	}
	// dbobj.Close()
	return true
}

//-------------------------------------------------------------------------------------------------------------
// insert AccountEmailStruct
//-------------------------------------------------------------------------------------------------------------
func accountEmailCreate(data AccountEmailStruct) bool {
	var err error
	// open, dbobj := OpendatabaseCandidate("Database/TempAccount/AccountEmailStruct")
	// if !open {
	// 	errorpk.AddError("opendatabase AccountEmailStruct package", "can't open the database", "critical error")
	// 	return false
	// }
	d, convert := globalPkg.ConvetToByte(data, "accountEmailCreate account package")
	if !convert {
		return false
	}
	err = DBEmail.Put([]byte(data.AccountEmail), d, nil)
	if err != nil {
		errorpk.AddError("AccountEmailStructCreate  AccountEmailStruct package", "can't create AccountEmailStruct", "runtime error")
		return false
	}
	// dbobj.Close()
	return true
}

//-------------------------------------------------------------------------------------------------------------
// insert AccountPhoneNumberStruct
//-------------------------------------------------------------------------------------------------------------
func accountPhoneNumberCreate(data AccountPhoneNumberStruct) bool {
	var err error
	// open, dbobj := OpendatabaseCandidate("Database/TempAccount/AccountPhoneNumberStruct")
	// if !open {
	// 	errorpk.AddError("opendatabase AccountPhoneNumberStruct package", "can't open the database", "critical error")
	// 	return false
	// }
	d, convert := globalPkg.ConvetToByte(data, "accountPhoneNumberCreate account package")
	if !convert {
		return false
	}
	err = DBPhoneNo.Put([]byte(data.AccountPhoneNumber), d, nil)
	if err != nil {
		errorpk.AddError("accountPhoneNumberCreate  AccountPhoneNumberStruct package", "can't create accountPhoneNumberStruct", "runtime error")
		return false
	}
	// dbobj.Close()
	return true
}

//-------------------------------------------------------------------------------------------------------------
// insert AccountLastUpdatedTimestruct
//-------------------------------------------------------------------------------------------------------------
func accountLastUpdatedTimeCreate(data AccountLastUpdatedTimestruct) bool {
	var err error
	// open, dbobj := OpendatabaseCandidate("Database/TempAccount/AccountLastUpdatedTimestruct")
	// if !open {
	// 	errorpk.AddError("opendatabase AccountLastUpdatedTimestruct package", "can't open the database", "critical error")
	// 	return false
	// }
	d, convert := globalPkg.ConvetToByte(data, "accountLastUpdateTimeCreate account package")
	if !convert {
		return false
	}
	err = DBLastUpdateTime.Put([]byte(data.AccountLastUpdatedTime.String()), d, nil)
	if err != nil {
		errorpk.AddError("AccountLastUpdatedTimestructCreate  AccountLastUpdatedTimestruct package", "can't create AccountLastUpdatedTimestruct", "runtime error")
		return false
	}
	// dbobj.Close()
	return true
}

//-------------------------------------------------------------------------------------------------------------
// insert AccountPublicKeystruct
//-------------------------------------------------------------------------------------------------------------
func accountPublicKeyCreate(data AccountPublicKeyStruct) bool {
	var err error
	// open, dbobj := OpendatabaseCandidate("Database/TempAccount/AccountPublicKeyStruct")
	// if !open {
	// 	errorpk.AddError("opendatabase AccountPublicKeystruct package", "can't open the database", "critical error")
	// 	return false
	// }
	d, convert := globalPkg.ConvetToByte(data, "accountPublicKeyCreate account package")
	if !convert {
		return false
	}
	err = DBPublicKey.Put([]byte(data.AccountPublicKey), d, nil)
	if err != nil {
		errorpk.AddError("AccountPublicKeyCreate  AccountPublicKeystruct package", "can't create AccountPublicKeystruct", "runtime error")
		return false
	}
	// dbobj.Close()
	return true
}

//-------------------------------------------------------------------------------------------------------------
// insert AccountStruct
//-------------------------------------------------------------------------------------------------------------
func accountCreate(data AccountStruct) bool {

	Opendatabase()
	var err error
	d, convert := globalPkg.ConvetToByte(data, "accountCreate account package")
	if !convert {
		return false
	}
	err = DB.Put([]byte(data.AccountIndex), d, nil)
	if err != nil {
		errorpk.AddError("AccountStructCreate  AccountStruct package", "can't create AccountStruct", "runtime error")
		return false
	}
	closedatabase()
	if err == nil {
		AccountStructObj := findAccountByAccountKey(data.AccountIndex)
		AccountNameStructObj := AccountNameStruct{AccountName: AccountStructObj.AccountName, AccountIndex: AccountStructObj.AccountIndex}
		err := accountNameCreate(AccountNameStructObj)
		if !err {
			errorpk.AddError("AccountNameStructCreate  AccountNameStruct package", "can't create AccountNameStruct", "runtime error")
			return false
		}
		if err {
			AccountEmailStructObj := AccountEmailStruct{AccountEmail: AccountStructObj.AccountEmail, AccountIndex: AccountStructObj.AccountIndex}
			err = accountEmailCreate(AccountEmailStructObj)
			if !err {
				errorpk.AddError("AccountEmailStructCreate  AccountEmailStruct package", "can't create AccountEmailStruct", "runtime error")
				return false
			}
			if err {
				AccountPhoneNumberStructObj := AccountPhoneNumberStruct{AccountPhoneNumber: AccountStructObj.AccountPhoneNumber, AccountIndex: AccountStructObj.AccountIndex}
				err = accountPhoneNumberCreate(AccountPhoneNumberStructObj)
				if !err {
					errorpk.AddError("AccountPhoneNumberStructCreate  AccountPhoneNumberStruct package", "can't create AccountPhoneNumberStruct", "runtime error")
					return false
				}
				if err {
					AccountLastUpdatedTimestructObj := AccountLastUpdatedTimestruct{AccountLastUpdatedTime: AccountStructObj.AccountLastUpdatedTime, AccountIndex: AccountStructObj.AccountIndex}
					err = accountLastUpdatedTimeCreate(AccountLastUpdatedTimestructObj)
					if !err {
						errorpk.AddError("AccountLastUpdatedTimestructCreate  AccountLastUpdatedTimestruct package", "can't create AccountLastUpdatedTimestruct", "runtime error")
						return false
					}
					if err {
						AccountPublicKeystructObj := AccountPublicKeyStruct{AccountPublicKey: AccountStructObj.AccountPublicKey, AccountIndex: AccountStructObj.AccountIndex}
						err = accountPublicKeyCreate(AccountPublicKeystructObj)
						if !err {
							errorpk.AddError("AccountPublicKeyStructCreate  AccountPublicKeyStruct package", "can't create AccountPublicKeyStruct", "runtime error")
							return false
						}
					}
				}
			}
		}
	}
	return true
}

//-------------------------------------------------------------------------------------------------------------
// select By key AccountStruct
//-------------------------------------------------------------------------------------------------------------
func findAccountByAccountKey(key string) (AccountStructObj AccountStruct) {

	Opendatabase()

	data, err := DB.Get([]byte(key), nil)

	if err != nil {
		errorpk.AddError("AccountStructFindByKey  AccountStruct package", "can't get AccountStruct", "runtime error")
	}
	json.Unmarshal(data, &AccountStructObj)
	closedatabase()
	return AccountStructObj
}

//-------------------------------------------------------------------------------------------------------------
// select By key AccountNameStruct
//-------------------------------------------------------------------------------------------------------------
func findAccountNameByKey(key string) (AccountNameStructObj AccountNameStruct, er bool) {
	var err error
	// open, dbobj := OpendatabaseCandidate("Database/TempAccount/AccountNameStruct")
	// if !open {
	// 	errorpk.AddError("opendatabase AccountNameStruct package", "can't open the database", "critical error")
	// 	return AccountNameStruct{}, false
	// }
	data, err := DBName.Get([]byte(key), nil)
	if err != nil {
		errorpk.AddError("AccountNameStructFindByKey  AccountNameStruct package", "can't get AccountNameStruct", "runtime error")
	}
	json.Unmarshal(data, &AccountNameStructObj)
	//dbobj.Close()
	return AccountNameStructObj, true
}

//-------------------------------------------------------------------------------------------------------------
// select By key AccountPublicKeyStruct
//-------------------------------------------------------------------------------------------------------------
func findAccountPublicKeyByKey(key string) (AccountPublicKeyStructObj AccountPublicKeyStruct, er bool) {
	var err error
	// open, dbobj := OpendatabaseCandidate("Database/TempAccount/AccountPublicKeyStruct")
	// if !open {
	// 	errorpk.AddError("opendatabase AccountPublicKeyStruct package", "can't open the database", "critical error")
	// 	return AccountPublicKeyStruct{}, false
	// }
	data, err := DBPublicKey.Get([]byte(key), nil)
	if err != nil {
		// fmt.Println("errrrr from AccountPubKey struct??", err)
		errorpk.AddError("AccountPublicKeyStructFindByKey  AccountPublicKeyStruct package", "can't get AccountPublicKeyStruct", "runtime error")
	}
	json.Unmarshal(data, &AccountPublicKeyStructObj)
	// dbobj.Close()
	return AccountPublicKeyStructObj, true
}

//-------------------------------------------------------------------------------------------------------------
// select By AccountName  AccountStruct
//-------------------------------------------------------------------------------------------------------------
func findAccountByAccountName(AccountName string) (AccountStructObj AccountStruct) {

	data, err := findAccountNameByKey(AccountName)
	if err {
		AccountStructObj = findAccountByAccountKey(data.AccountIndex)
	}
	return AccountStructObj
}

//-------------------------------------------------------------------------------------------------------------
// select By key AccountEmailStruct
//-------------------------------------------------------------------------------------------------------------
func findAccountEmailByKey(key string) (AccountEmailStructObj AccountEmailStruct, er bool) {
	var err error
	// open, dbobj := OpendatabaseCandidate("Database/TempAccount/AccountEmailStruct")
	// if !open {
	// 	fmt.Println("######################################")
	// 	errorpk.AddError("opendatabase AccountEmailStruct package", "can't open the database", "critical error")
	// 	return AccountEmailStruct{}, false
	// }
	data, err := DBEmail.Get([]byte(key), nil)
	if err != nil {
		fmt.Println("&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&")
		errorpk.AddError("AccountEmailStructFindByKey  AccountEmailStruct package", "can't get AccountEmailStruct", "runtime error")
	}
	json.Unmarshal(data, &AccountEmailStructObj)
	// dbobj.Close()
	// fmt.Println("    ^^v      Obj        ^^  ", AccountEmailStructObj)
	return AccountEmailStructObj, true
}

//-------------------------------------------------------------------------------------------------------------
// select By AccountEmail  AccountStruct
//-------------------------------------------------------------------------------------------------------------
func findAccountByAccountEmail(AccountEmail string) (AccountStructObj AccountStruct) {

	data, err := findAccountEmailByKey(AccountEmail)
	fmt.Println("    ***********    objjjjj      ---   ", data)
	if err {
		AccountStructObj = findAccountByAccountKey(data.AccountIndex)
	}
	fmt.Println(" -*****         obj db       ----  ", AccountStructObj)
	return AccountStructObj
}

//-------------------------------------------------------------------------------------------------------------
// select By key AccountPhoneNumberStruct
//-------------------------------------------------------------------------------------------------------------

func findAccountPhoneNumberByKey(key string) (AccountPhoneNumberStructObj AccountPhoneNumberStruct, er bool) {
	var err error
	// open, dbobj := OpendatabaseCandidate("Database/TempAccount/AccountPhoneNumberStruct")
	// if !open {
	// 	errorpk.AddError("opendatabase AccountPhoneNumberStruct package", "can't open the database", "critical error")
	// 	return AccountPhoneNumberStruct{}, false
	// }
	data, err := DBPhoneNo.Get([]byte(key), nil)
	if err != nil {
		errorpk.AddError("AccountPhoneNumberStructFindByKey  AccountPhoneNumberStruct package", "can't get AccountPhoneNumberStruct", "runtime error")
	}
	json.Unmarshal(data, &AccountPhoneNumberStructObj)
	//dbobj.Close()
	return AccountPhoneNumberStructObj, true
}

//-------------------------------------------------------------------------------------------------------------
// select By PhoneNumber  AccountStruct
//-------------------------------------------------------------------------------------------------------------
func findAccountByAccountPhoneNumber(AccountPhoneNumber string) (AccountStructObj AccountStruct) {

	data, err := findAccountPhoneNumberByKey(AccountPhoneNumber)
	if err {
		AccountStructObj = findAccountByAccountKey(data.AccountIndex)
	}
	return AccountStructObj
}

//-------------------------------------------------------------------------------------------------------------
// select By PhoneNumber  AccountStruct
//-------------------------------------------------------------------------------------------------------------
func findAccountByAccountPublicKey(AccountPublicKey string) (AccountStructObj AccountStruct) {

	data, err := findAccountPublicKeyByKey(AccountPublicKey)
	if err {
		AccountStructObj = findAccountByAccountKey(data.AccountIndex)
	}
	return AccountStructObj
}

//-------------------------------------------------------------------------------------------------------------
// select By key AccountLastUpdatedTimeStruct
//-------------------------------------------------------------------------------------------------------------
func findAccountLastUpdatedTimeByKey(key string) (AccountLastUpdatedTimestructObj AccountLastUpdatedTimestruct, er bool) {
	var err error
	// open, dbobj := OpendatabaseCandidate("Database/TempAccount/AccountLastUpdatedTimestruct")
	// if !open {
	// 	errorpk.AddError("opendatabase AccountLastUpdatedTimestruct package", "can't open the database", "critical error")
	// 	return AccountLastUpdatedTimestruct{}, false
	// }
	data, err := DBLastUpdateTime.Get([]byte(key), nil)
	if err != nil {
		errorpk.AddError("AccountLastUpdatedTimestructFindByKey  AccountLastUpdatedTimestruct package", "can't get AccountLastUpdatedTimestruct", "runtime error")
	}
	json.Unmarshal(data, &AccountLastUpdatedTimestructObj)
	// dbobj.Close()
	return AccountLastUpdatedTimestructObj, true
}

//-------------------------------------------------------------------------------------------------------------
// select By AccountLastUpdatedTime  AccountStruct
//-------------------------------------------------------------------------------------------------------------
func findAccountByAccountLastUpdatedTime(AccountLastUpdatedTime string) (AccountStructObj AccountStruct) {

	data, err := findAccountLastUpdatedTimeByKey(AccountLastUpdatedTime)
	if err {
		AccountStructObj = findAccountByAccountKey(data.AccountIndex)
	}
	return AccountStructObj
}

//-------------------------------------------------------------------------------------------------------------
// get all AccountStruct
//-------------------------------------------------------------------------------------------------------------
func GetAllAccounts() (values []AccountStruct) {
	Opendatabase()
	iter := DB.NewIterator(nil, nil)
	for iter.Next() {

		value := iter.Value()
		var newdata AccountStruct
		json.Unmarshal(value, &newdata)
		values = append(values, newdata)
	}
	closedatabase()

	return values
}

//-------------------------------------------------------------------------------------------------------------
// get all AccountStruct
//-------------------------------------------------------------------------------------------------------------
func getLastAccount() (values AccountStruct) {
	Opendatabase()
	iter := DB.NewIterator(nil, nil)
	iter.Last()
	value := iter.Value()
	var newdata AccountStruct
	json.Unmarshal(value, &newdata)
	values = newdata

	closedatabase()

	return values
}

func GetFirstAccount() (values AccountStruct) {
	Opendatabase()
	iter := DB.NewIterator(nil, nil)
	iter.First()
	value := iter.Value()
	var newdata AccountStruct
	json.Unmarshal(value, &newdata)
	values = newdata

	closedatabase()

	return values
}

/////////////////////////////
// update AccountStruct
//-------------------------------------------------------------------------------------------------------------
func accountUpdate(data AccountStruct) bool {
	fmt.Println("+++++++++++++++++++++++++++")
	AccountStructObj := findAccountByAccountKey(data.AccountIndex)
	err := accountNameDelete(AccountStructObj.AccountName)
	if err {
		err = accountEmailDelete(AccountStructObj.AccountEmail)
		if err {
			err = accountPhoneNumberDelete(AccountStructObj.AccountPhoneNumber)
			if err {
				err = accountLastUpdatedTimeDelete(AccountStructObj.AccountLastUpdatedTime.String())
				if err {
					err = accountPublicKeyDelete(AccountStructObj.AccountPublicKey)
					if err {
						err = accountCreate(data)
					} else {
						return false
					}
				} else {
					return false
				}
			} else {
				return false
			}
		} else {
			return false
		}
	} else {
		return false
	}
	return true
}

// delete AccountNameStruct
//-------------------------------------------------------------------------------------------------------------
func accountNameDelete(AccountName string) bool {
	var err error
	// open, dbobj := OpendatabaseCandidate("Database/TempAccount/AccountNameStruct")
	// if !open {
	// 	errorpk.AddError("opendatabase AccountNameStruct package", "can't open the database", "critical error")
	// 	return false
	// }
	err = DBName.Delete([]byte(AccountName), nil)
	if err != nil {
		errorpk.AddError("AccountNameDelete  AccountNameStruct package", "can't delete AccountNameStruct", "runtime error")
		return false
	}
	// dbobj.Close()
	return true
}

// delete AccountEmailStruct
//-------------------------------------------------------------------------------------------------------------
func accountEmailDelete(AccountEmail string) bool {
	var err error
	// open, dbobj := OpendatabaseCandidate("Database/TempAccount/AccountEmailStruct")
	// if !open {
	// 	errorpk.AddError("opendatabase AccountEmailStruct package", "can't open the database", "critical error")
	// 	return false
	// }
	err = DBEmail.Delete([]byte(AccountEmail), nil)
	if err != nil {
		errorpk.AddError("AccountEmailStructDelete  AccountEmailStruct package", "can't delete AccountEmailStruct", "runtime error")
		return false
	}
	// dbobj.Close()
	return true
}

// delete AccountPhoneNumberStruct
//-------------------------------------------------------------------------------------------------------------
func accountPhoneNumberDelete(AccountPhoneNumber string) bool {
	var err error
	// open, dbobj := OpendatabaseCandidate("Database/TempAccount/AccountPhoneNumberStruct")
	// if !open {
	// 	errorpk.AddError("opendatabase AccountPhoneNumberStruct package", "can't open the database", "critical error")
	// 	return false
	// }
	err = DBPhoneNo.Delete([]byte(AccountPhoneNumber), nil)
	if err != nil {
		errorpk.AddError("accountPhoneNumberDelete  AccountPhoneNumberStruct package", "can't delete accountPhoneNumberStruct", "runtime error")
		return false
	}
	// dbobj.Close()
	return true
}

//delete AccountLastUpdatedTimestruct
//-------------------------------------------------------------------------------------------------------------
func accountLastUpdatedTimeDelete(AccountLastUpdatedTime string) bool {
	var err error
	// open, dbobj := OpendatabaseCandidate("Database/TempAccount/AccountLastUpdatedTimestruct")
	// if !open {
	// 	errorpk.AddError("opendatabase AccountLastUpdatedTimestruct package", "can't open the database", "critical error")
	// 	return false
	// }
	err = DBLastUpdateTime.Delete([]byte(AccountLastUpdatedTime), nil)
	if err != nil {
		errorpk.AddError("AccountLastUpdatedTimestructDelete  AccountLastUpdatedTimestruct package", "can't delete AccountLastUpdatedTimestruct", "runtime error")
		return false
	}
	// dbobj.Close()
	return true
}

// delete AccountPublicKeystruct
//-------------------------------------------------------------------------------------------------------------
func accountPublicKeyDelete(AccountPublicKey string) bool {
	var err error
	// open, dbobj := OpendatabaseCandidate("Database/TempAccount/AccountPublicKeyStruct")
	// if !open {
	// 	errorpk.AddError("opendatabase AccountPublicKeystruct package", "can't open the database", "critical error")
	// 	return false
	// }
	err = DBPublicKey.Delete([]byte(AccountPublicKey), nil)
	if err != nil {
		errorpk.AddError("AccountPublicKeyDelete  AccountPublicKeystruct package", "can't delete AccountPublicKeystruct", "runtime error")
		return false
	}
	// dbobj.Close()
	return true
}

//------------------------------------------------------------------------------------------------------------
// close db if exist
//------------------------------------------------------------------------------------------------------------
func closedatabase() bool {
	// var err error
	// err = DB.Close()
	// if err != nil {
	// 	errorpk.AddError("closedatabase AccountStruct package", "can't close the database")
	// 	return false
	// }
	return true
}

func accountUpdate2(data AccountStruct) bool {

	Opendatabase()
	var err error
	d, convert := globalPkg.ConvetToByte(data, "accountCreate account package")
	if !convert {
		return false
	}
	err = DB.Put([]byte(data.AccountIndex), d, nil)
	if err != nil {
		errorpk.AddError("AccountStructCreate  AccountStruct package", "can't create AccountStruct", "runtime error")
		return false
	}
	closedatabase()

	return true

}

//addBKey adding public key to the account when it's confirm that the user dowenloaded private key
func addBKey(accountObj AccountStruct) bool {
	accountObj.AccountLastUpdatedTime, _ = time.Parse("2006-01-02 15:04:05:06 PM -0000", time.Now().UTC().Format("2006-01-02 15:04:05:06 PM -0000"))
	if accountCreate(accountObj) {
		return true
	}
	return false
}

//newIndex return the next empty index to be used
func newIndex() string {
	LastIndex := getLastIndex()
	index := 0
	if LastIndex != "-1" {
		// TODO : split LastIndex
		res := strings.Split(LastIndex, "_")
		if len(res) == 2 {
			index = globalPkg.ConvertFixedLengthStringtoInt(res[1]) + 1
		} else {
			index = globalPkg.ConvertFixedLengthStringtoInt(LastIndex) + 1
		}
	}
	timpIndex, _ := globalPkg.ConvertIntToFixedLengthString(index, globalPkg.GlobalObj.StringFixedLength)
	i, _ := strconv.Atoi(timpIndex)
	var currentIndex = ""
	if i > 0 {
		currentIndex = getHash([]byte(validator.CurrentValidator.ValidatorIP)) + "_" + timpIndex
	} else {
		currentIndex = timpIndex
	}
	log.Println("current index ", currentIndex)
	return currentIndex
}
