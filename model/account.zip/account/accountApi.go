package account

import (
	"encoding/json"
	"net"
	"net/http"
	"time"

	"../admin"
	"../globalPkg"
	"../logpkg"
)

/*----------------- -----------------------API------------------------------------------------*/
/*----------------- endpoint to broadcast adding or updating the account through the network  -----------------*/
// func AccountBroadCastAPI(w http.ResponseWriter, req *http.Request) {

// 	w.Header().Set("Content-Type", "application/json")
// 	accountObj := AccountStruct{}
// 	err := json.NewDecoder(req.Body).Decode(&accountObj)
// 	errStr := ""
// 	if err != nil {
// 		errStr = errorpk.AddError("Broadcast AccountStruct API AccountStruct package"+req.Method, "can't convert body to AccountStruct obj")

// 	} else {
// 		for _, validatorObj := range validator.ValidatorsLstObj {

// 			url := validatorObj.ValidatorIP
// 			switch req.Method {
// 			case "POST":
// 				url = url + "/RegisterAccount"
// 			case "PUT":
// 				url = url + "/UpdateAccount"
// 			default:
// 				{
// 					errStr = errorpk.AddError("Broadcast Validator API validator package"+req.Method, "wrong method")
// 				}
// 			}

// 			jsonObj, _ := json.Marshal(accountObj)
// 			errStr = errStr + globalPkg.SendRequest(jsonObj, url, req.Method)
// 		}
// 	}
// 	if errStr == "" {
// 		sendJson, _ := json.Marshal(accountObj)
// 		w.Header().Set("Content-Type", "application/json")
// 		w.WriteHeader(http.StatusOK)
// 		w.Write(sendJson)
// 	} else {
// 		w.WriteHeader(http.StatusInternalServerError)
// 		w.Write([]byte(errStr))
// 	}

// }

// /*----------------- endpoint to add or update account in the miner  -----------------*/
// func AccountAPI(w http.ResponseWriter, req *http.Request) {

// 	w.Header().Set("Content-Type", "application/json")
// 	accountObj := AccountStruct{}
// 	errorStr := ""

// 	err := json.NewDecoder(req.Body).Decode(&accountObj)
// 	if err != nil {
// 		errorStr = errorpk.AddError("AccountStruct API AccountStruct package"+req.Method, "Can't convert Body to AccountStruct obj ")
// 	} else {
// 		defer req.Body.Close()

// 		switch req.Method {
// 		case "POST":
// 			errorStr = AddAccount(accountObj)
// 		case "PUT":
// 			errorStr = updateAccount(accountObj)
// 		default:
// 			errorStr = errorpk.AddError("AccountStruct API AccountStruct package"+req.Method, "wrong method ")

// 		}

// 		if errorStr != "" {
// 			w.WriteHeader(http.StatusInternalServerError)
// 			w.Write([]byte(errorStr))
// 		} else {
// 			sendJson, _ := json.Marshal(accountObj)
// 			w.Header().Set("Content-Type", "application/json")
// 			w.WriteHeader(http.StatusOK)
// 			w.Write(sendJson)
// 		}
// 	}
// }

/*----------------- endpoint to get all accounts from the miner  -----------------*/
func GetAllAccountsAPI(w http.ResponseWriter, req *http.Request) {
	//log
	now, _ := time.Parse("2006-01-02 03:04:05 PM -0000", time.Now().UTC().Format("2006-01-02 03:04:05 PM -0000"))
	ip, _, _ := net.SplitHostPort(req.RemoteAddr)
	userIP := net.ParseIP(ip)
	logobj := logpkg.LogStruct{now, userIP, "macAdress", "GetAllAccount", "Account", "_", "_", "_"}

	// Adminobj := globalPkg.AdminStruct{}
	Adminobj := admin.Admin{}
	//json.NewDecoder(req.Body).Decode(&Adminobj)
	decoder := json.NewDecoder(req.Body)
	decoder.DisallowUnknownFields()
	err := decoder.Decode(&Adminobj)

	if err != nil {
		globalPkg.SendError(w, "please enter your correct request ")
		logobj.OutputData = "Faild to Decode Admin Object"
		logobj.Process = "faild"
		logpkg.WriteOnlogFile(logobj)
		return
	}
	// if Adminobj.AdminUsername == globalPkg.AdminObj.AdminUsername && Adminobj.AdminPassword == globalPkg.AdminObj.AdminPassword {
	if admin.ValidationAdmin(Adminobj) {
		jsonObj, _ := json.Marshal(GetAllAccounts())
		globalPkg.SendResponse(w, jsonObj)
		logobj.OutputData = "get all accounts"
		logobj.Process = "success"
		logpkg.WriteOnlogFile(logobj)

	} else {

		globalPkg.SendError(w, "you are not the admin ")
		logobj.OutputData = "you are not the admin to get all accounts "
		logobj.Process = "fail"
		logpkg.WriteOnlogFile(logobj)
	}
}

/*----------------- endpoint to get specific account using public key from the miner  -----------------*/
func GetAccountInfoByAccountPublicKeyAPI(w http.ResponseWriter, req *http.Request) {
	//log
	now, _ := time.Parse("2006-01-02 03:04:05 PM -0000", time.Now().UTC().Format("2006-01-02 03:04:05 PM -0000"))
	ip, _, _ := net.SplitHostPort(req.RemoteAddr)
	userIP := net.ParseIP(ip)
	logobj := logpkg.LogStruct{now, userIP, "macAdress", "GetAccountInfoByAccountPublicKeyAPI", "Account", "_", "_", "_"}

	var AccountPublicKey string

	decoder := json.NewDecoder(req.Body)
	decoder.DisallowUnknownFields()
	err := decoder.Decode(&AccountPublicKey)

	if err != nil {
		//http.Error(w, err.Error()+"  please enter your correct request", http.StatusBadRequest)
		globalPkg.SendError(w, "please enter your correct request ")
		logobj.OutputData = "Faild to Decode Object"
		logobj.Process = "faild"
		logpkg.WriteOnlogFile(logobj)
		return
	}
	AccountObj := findAccountByAccountPublicKey(AccountPublicKey)
	if AccountObj.AccountPublicKey == "" {
		// w.WriteHeader(http.StatusInternalServerError)
		// w.Write([]byte(errorpk.AddError("GetAccountInfoByAccountPublicKeyAPI", "Can't find the obj "+AccountPublicKey)))
		globalPkg.SendError(w, "Can't find the obj "+AccountPublicKey)
		logobj.OutputData = "Can't find the obj by this publickey" + AccountPublicKey + "\n"
		logobj.Process = "faild"
		logpkg.WriteOnlogFile(logobj)
	} else {
		jsonObj, _ := json.Marshal(findAccountByAccountPublicKey(AccountPublicKey))
		globalPkg.SendResponse(w, jsonObj)
		logobj.OutputData = "find object by  this publickey" + AccountPublicKey + "\n"
		logobj.Process = "success"
		logpkg.WriteOnlogFile(logobj)
	}
}

//EmailuserStruct email and name
type EmailuserStruct struct {
	Name  string
	Email string
}

//GetAllEmailsUsernameAPI get all emails and names
func GetAllEmailsUsernameAPI(w http.ResponseWriter, req *http.Request) {

	//log
	now, _ := time.Parse("2006-01-02 03:04:05 PM -0000", time.Now().UTC().Format("2006-01-02 03:04:05 PM -0000"))
	ip, _, _ := net.SplitHostPort(req.RemoteAddr)
	userIP := net.ParseIP(ip)
	logobj := logpkg.LogStruct{now, userIP, "macAdress", "GetAllEmailsUsernameAPI", "Account", "_", "_", "_"}

	Adminobj := admin.Admin{}

	decoder := json.NewDecoder(req.Body)
	decoder.DisallowUnknownFields()
	err := decoder.Decode(&Adminobj)

	if err != nil {
		globalPkg.SendError(w, "please enter your correct request ")
		logobj.OutputData = "Faild to Decode Object"
		logobj.Process = "faild"
		logpkg.WriteOnlogFile(logobj)
		return
	}

	// var sendJSON []byte
	arrEmailsUsername := []EmailuserStruct{}

	if admin.ValidationAdmin(Adminobj) {
		accountobj := GetAllAccounts()
		for _, account := range accountobj {
			emailsUsername := EmailuserStruct{account.AccountName, account.AccountEmail}
			arrEmailsUsername = append(arrEmailsUsername, emailsUsername)
		}

		jsonObj, _ := json.Marshal(arrEmailsUsername)
		globalPkg.SendResponse(w, jsonObj)
		logobj.OutputData = "success to get all emails and username"
		logobj.Process = "success"
		logpkg.WriteOnlogFile(logobj)
	} else {
		globalPkg.SendError(w, "you are not admin ")
		logobj.OutputData = "you are not the admin to get all Emails and username "
		logobj.Process = "fail"
		logpkg.WriteOnlogFile(logobj)
	}

}

//GetnumberAccountsAPI get number of accounts
func GetnumberAccountsAPI(w http.ResponseWriter, req *http.Request) {

	//log
	now, _ := time.Parse("2006-01-02 03:04:05 PM -0000", time.Now().UTC().Format("2006-01-02 03:04:05 PM -0000"))
	ip, _, _ := net.SplitHostPort(req.RemoteAddr)
	userIP := net.ParseIP(ip)
	logobj := logpkg.LogStruct{now, userIP, "macAdress", "GetnumberAccountsAPI", "Account", "_", "_", "_"}

	Adminobj := admin.Admin{}

	decoder := json.NewDecoder(req.Body)
	decoder.DisallowUnknownFields()
	err := decoder.Decode(&Adminobj)

	if err != nil {
		globalPkg.SendError(w, "please enter your correct request ")
		logobj.OutputData = "Faild to Decode Object"
		logobj.Process = "faild"
		logpkg.WriteOnlogFile(logobj)
		return
	}

	if admin.ValidationAdmin(Adminobj) {
		data := map[string]interface{}{
			"Number_Of_Accounts": len(GetAllAccounts()),
		}
		jsonObj, _ := json.Marshal(data)
		globalPkg.SendResponse(w, jsonObj)
		logobj.OutputData = "success to get number of accounts"
		logobj.Process = "success"
		logpkg.WriteOnlogFile(logobj)
	} else {
		globalPkg.SendError(w, "you are not admin ")
		logobj.OutputData = "you are not the admin to get all Emails and username "
		logobj.Process = "fail"
		logpkg.WriteOnlogFile(logobj)
	}
}
