﻿package account

import (
	"encoding/json"
	"fmt"
	"log"
	"net"
	"net/http"
	"strings"
	"time"

	"../broadcastTcp"
	"../errorpk"
	"../globalPkg"
	"../logpkg"
	session "../session"
	validator "../validator"
)

type savekey struct {
	PublicKey string
	Passsword string
	Email     string
}

type DelSession struct {
	AccounIndex string
	SessionID   string
	Passord     string
}

//-----End point call called to confim new user and save
//-------save new user in database -------------------
func ConfirmationMessage(w http.ResponseWriter, req *http.Request) {

	now, _ := time.Parse("2006-01-02 03:04:05 PM -0000", time.Now().UTC().Format("2006-01-02 03:04:05 PM -0000"))
	ip, _, _ := net.SplitHostPort(req.RemoteAddr)
	userIP := net.ParseIP(ip)
	logobj := logpkg.LogStruct{now, userIP, "macAdress", "ConfirmationMessage", "AccountModule", "", "", "_"}

	confmationCode := stringmessage{}
	decoder := json.NewDecoder(req.Body)
	decoder.DisallowUnknownFields()
	err := decoder.Decode(&confmationCode)
	if err != nil {
		globalPkg.SendError(w, "please enter your correct request ")
		logobj.OutputData = "Faild to Decode Object"
		logobj.Process = "faild"
		logpkg.WriteOnlogFile(logobj)
		return
	}

	logobj.InputData = confmationCode.Message

	user := User{}

	var message string
	message, user = confirmationProcess(user, confmationCode.Message, now)

	if message != "" {
		//sendResponse(w, message)
		globalPkg.SendError(w, message)
		logobj.OutputData = message
		logobj.Process = "faild"
		logpkg.WriteOnlogFile(logobj)
		return
	}
	if user.Method == "POST" {
		cryptoDataObj := cryptoData{}

		cryptoDataObj.PublicKey = user.Account.AccountPublicKey
		cryptoDataObj.PrivateKey = user.Account.AccountPrivateKey
		sendJson, _ := json.Marshal(cryptoDataObj)

		globalPkg.SendResponse(w, sendJson)
		logobj.OutputData = "Congratulations"
		logobj.Process = "success"
		logpkg.WriteOnlogFile(logobj)

		return

	}
	if user.Method == "PUT" {
		globalPkg.SendResponseMessage(w, "Congratulations")
	}

}

//UserRegister End point create new Account
func UserRegister(w http.ResponseWriter, req *http.Request) {
	logStruct := logpkg.LogStruct{}

	//fmt.Println("**-----ip---", userIP.String())
	logStruct.Function = "userRegister"
	logStruct.Module = "account"

	userObj := User{}
	RandomCode := encodeToString(globalPkg.GlobalObj.MaxConfirmcode)
	userObj.Confirmation_code = RandomCode
	userObj.Method = "POST"
	decoder := json.NewDecoder(req.Body)
	decoder.DisallowUnknownFields()
	err := decoder.Decode(&userObj.Account)
	if err != nil {
		globalPkg.SendError(w, "please enter your correct request ")
		logStruct.OutputData = "Faild to Decode Object"
		logStruct.Process = "faild"
		logpkg.WriteOnlogFile(logStruct)
		return
	}
	// err := json.NewDecoder(req.Body).Decode(&userObj)

	// if err != nil {
	// 	logStruct.Process = "faild"
	// 	logStruct.OutputData = "Faild to read user object"

	// 	//logStruct.CurrentTime = time.Now
	// 	logpkg.WriteOnlogFile(logStruct)

	// 	log.Printf("Failed unmarshaling : %s\n", err)

	// 	sendResponse(w, "Faild to read user object")
	// 	return

	// }
	InputData := userObj.Account.AccountName + "," + userObj.Account.AccountEmail + "," + userObj.Account.AccountPhoneNumber + userObj.Account.AccountPassword
	logStruct.InputData = InputData

	//check username and email is lowercase
	userObj.Account.AccountEmail = convertStringTolowerCaseAndtrimspace(userObj.Account.AccountEmail)
	userObj.Account.AccountName = convertStringTolowerCaseAndtrimspace(userObj.Account.AccountName)
	//check if account exist or Any feild found before
	var Error string
	var accountStruct AccountStruct
	Error = userValidation(userObj)
	if Error != "" {
		globalPkg.SendError(w, Error)
		logStruct.Process = "faild"
		logStruct.OutputData = "errorin validate user :" + Error + "\n"
		logpkg.WriteOnlogFile(logStruct)

		//sendResponse(w, Error)

		return
	}
	accountStruct = convertUserTOAccount(userObj)

	var current time.Time
	current, _ = time.Parse("2006-01-02 03:04:05 PM -0000", time.Now().UTC().Format("2006-01-02 03:04:05 PM -0000"))

	userObj.CurrentTime = current
	fmt.Println("registration :   ", userObj.CurrentTime)
	Error = sendConfirmationEmailORSMS(userObj)
	if Error != "" {
		globalPkg.SendError(w, "sms not send NO internet connection ")
		logStruct.Process = "faild"
		logStruct.OutputData = "sms not send NO internet connection " + Error + "\n"
		logpkg.WriteOnlogFile(logStruct)

		return
	}

	//userobjlst = append(userobjlst, userObj)
	// var list []string
	// list = append(list, userObj.CurrentTime.Format("2006-01-02 03:04:05 PM -0000"))
	// broadcastTcp.BoardcastingTCP(userObj, validator.CurrentValidator.ValidatorPublicKey, "adduser", "account module", list)
	broadcastTcp.BoardcastingTCP(userObj, "adduser", "account module")
	//addUserIntemp(userObj)
	sendJson, _ := json.Marshal(accountStruct)
	globalPkg.SendResponse(w, sendJson)

	logStruct.Process = "success"
	logStruct.OutputData = "user successfully registered" + "\n"
	logpkg.WriteOnlogFile(logStruct)

	// w.Header().Set("Content-Type", "application/json")
	// w.WriteHeader(http.StatusOK)
	// w.Write(sendJson)
}

//-------------UpdateAccountInfo End Point------------
//------------this Api call by front End to make user to
//---------------update his account info-------

func UpdateAccountInfo(w http.ResponseWriter, req *http.Request) {
	now, _ := time.Parse("2006-01-02 03:04:05 PM -0000", time.Now().UTC().Format("2006-01-02 03:04:05 PM -0000"))

	user := User{}
	user.Method = "PUT"
	RandomCode := encodeToString(globalPkg.GlobalObj.MaxConfirmcode)
	//------------------ log file structure -------------------------------
	ip, _, _ := net.SplitHostPort(req.RemoteAddr)
	userIP := net.ParseIP(ip)
	logobj := logpkg.LogStruct{now, userIP, "macAdress", "UpdateAccountInfo", "AccountModule", "", "", "_"}
	decoder := json.NewDecoder(req.Body)
	decoder.DisallowUnknownFields()
	err := decoder.Decode(&user)
	if err != nil {
		globalPkg.SendError(w, "please enter your correct request ")
		logobj.OutputData = "Faild to Decode Object"
		logobj.Process = "faild"
		logpkg.WriteOnlogFile(logobj)
		return
	}

	InputData := user.Account.AccountName + "," + user.Account.AccountEmail + "," + user.Account.AccountPhoneNumber + user.Account.AccountPassword
	logobj.InputData = InputData

	//approve username & email is lowercase and trim
	user.Account.AccountEmail = convertStringTolowerCaseAndtrimspace(user.Account.AccountEmail)
	user.Account.AccountName = convertStringTolowerCaseAndtrimspace(user.Account.AccountName)

	var accountObj AccountStruct
	accountObj = findAccountByAccountPublicKey(user.Account.AccountPublicKey)
	if accountObj.AccountPassword != user.Oldpassword {
		globalPkg.SendError(w, "Invalid Pasword")
		logobj.OutputData = "Invalid Pasword"
		logobj.Process = "faild"
		logpkg.WriteOnlogFile(logobj)

		return

	}
	//check if account exist
	var accountStruct AccountStruct

	//accountStruct = convertUserTOAccount(user)
	accountStruct = user.Account
	MessageErr := checkingIfAccountExixtsBeforeUpdating(accountStruct)
	if MessageErr != "" {
		globalPkg.SendNotFound(w, MessageErr)
		logobj.OutputData = MessageErr
		logobj.Process = "faild"
		logpkg.WriteOnlogFile(logobj)

		return
	}

	index, ErrorFound := checkFoundInUserList(user)

	if index == -2 {
		globalPkg.SendError(w, ErrorFound)
		logobj.OutputData = ErrorFound
		logobj.Process = "faild"
		logpkg.WriteOnlogFile(logobj)

		return
	}
	if index != -1 {

		removeUserFromtemp(index) ///remove old Request

	}

	user.Confirmation_code = RandomCode
	current, _ := time.Parse("2006-01-02 03:04:05 PM -0000", time.Now().UTC().Format("2006-01-02 03:04:05 PM -0000"))
	user.CurrentTime = current

	if user.Account.AccountEmail == accountObj.AccountEmail && accountObj.AccountEmail != "" {
		//	updatedaccountobj := convertUserTOAccount(userobject)

		accountObj.AccountName = accountStruct.AccountName
		accountObj.AccountPassword = accountStruct.AccountPassword
		accountObj.AccountPhoneNumber = accountStruct.AccountPhoneNumber
		accountObj.AccountAddress = accountStruct.AccountAddress
		//	accountobj.AccountEmail = accountStruct.AccountEmail
		///	accountobj.AccountPublicKey = accountStruct.AccountPublicKey

		// var lst []string
		// lst = append(lst, accountObj.AccountLastUpdatedTime.Format("2006-01-02 03:04:05 PM -0000"))
		broadcastTcp.BoardcastingTCP(accountObj, "PUT", "account")
		// broadcastTcp.BoardcastingTCP(accountObj, validator.CurrentValidator.ValidatorPublicKey, "PUT", "account", lst)
		sendJson, _ := json.Marshal(accountObj)
		globalPkg.SendResponse(w, sendJson)

		logobj.OutputData = accountObj.AccountName + "Update success"
		logobj.Process = "success"
		logpkg.WriteOnlogFile(logobj)

		return
	}

	ErrMessage := sendConfirmationEmailORSMS(user)
	if ErrMessage != "" {
		logobj.OutputData = "sms not send NO internet connection"
		logobj.Process = "faild"
		logpkg.WriteOnlogFile(logobj)

		globalPkg.SendError(w, "sms not send NO internet connection ")
		return
	}
	//addUserIntemp(user) ///Add update Request in userobj Arrary
	// var list []string
	// list = append(list, user.CurrentTime.Format("2006-01-02 03:04:05 PM -0000"))
	// broadcastTcp.BoardcastingTCP(user, validator.CurrentValidator.ValidatorPublicKey, "adduser", "account module", list)
	broadcastTcp.BoardcastingTCP(user, "adduser", "account module") ////Ass updated user in temp

	sendJson, _ := json.Marshal(accountStruct)
	globalPkg.SendResponse(w, sendJson)
	log.Printf("this is your data: %#v\n", user)
	logobj.OutputData = "user"
	logobj.Process = "success"
	logpkg.WriteOnlogFile(logobj)
}

//-------ChangeStatus End Point-----------------------------
// ---------to make user change his status
//---------from active  to deactive OR from deactive to active
//
func ChangeStatus(w http.ResponseWriter, req *http.Request) {
	//log
	now, _ := time.Parse("2006-01-02 03:04:05 PM -0000", time.Now().UTC().Format("2006-01-02 03:04:05 PM -0000"))
	ip, _, _ := net.SplitHostPort(req.RemoteAddr)
	userIP := net.ParseIP(ip)
	logobj := logpkg.LogStruct{now, userIP, "macAdress", "ChangeStatus", "AccountModule", "_", "_", "_"}

	DeactivationData := deactivateInfo{}
	decoder := json.NewDecoder(req.Body)
	decoder.DisallowUnknownFields()
	err := decoder.Decode(&DeactivationData)
	if err != nil {
		globalPkg.SendError(w, "please enter your correct request ")
		logobj.OutputData = "please enter your correct request "
		logobj.Process = "faild"
		logpkg.WriteOnlogFile(logobj)
		return
	}

	//approve username is lowercase and trim
	DeactivationData.UserName = convertStringTolowerCaseAndtrimspace(DeactivationData.UserName)
	accountObjByPK := findAccountByAccountPublicKey(DeactivationData.PublicKey)
	if accountObjByPK.AccountPublicKey == "" {
		globalPkg.SendError(w, "Invalid PUblicKey")
		logobj.OutputData = "Invalid PUblicKey "
		logobj.Process = "faild"
		logpkg.WriteOnlogFile(logobj)
		return
	}

	if DeactivationData.UserName != accountObjByPK.AccountName || DeactivationData.Password != accountObjByPK.AccountPassword {
		globalPkg.SendNotFound(w, "invalid UserNAme OR passsword ")
		logobj.OutputData = "invalid UserNAme OR passsword "
		logobj.Process = "faild"
		logpkg.WriteOnlogFile(logobj)
		return
	}

	accountObjByPK.AccountStatus = !accountObjByPK.AccountStatus
	accountObjByPK.AccountDeactivatedReason = DeactivationData.DeactivationReason

	broadcastTcp.BoardcastingTCP(accountObjByPK, "update2", "account")
	sendJson, _ := json.Marshal(accountObjByPK)
	globalPkg.SendResponse(w, sendJson)
	logobj.OutputData = "update status successful "
	logobj.Process = "success"
	logpkg.WriteOnlogFile(logobj)

}

//ConfirmatinByEmail this End point call when user press on
//------confirmation link delivered using Email
///-------if Data Valid then redirect user to login page
func ConfirmatinByEmail(w http.ResponseWriter, req *http.Request) {
	now, _ := time.Parse("2006-01-02 03:04:05 PM -0000", time.Now().UTC().Format("2006-01-02 03:04:05 PM -0000"))

	ip, _, _ := net.SplitHostPort(req.RemoteAddr)
	userIP := net.ParseIP(ip)
	logobj := logpkg.LogStruct{now, userIP, "macAdress", "ConfirmationByEmail", "AccountModule", "_", "_", "_"}

	var userObj User

	keys, ok := req.URL.Query()["confirmationcode"] // values.Get("confirmationcode") //return parameter from url

	if !ok || len(keys) == 0 {
		globalPkg.SendNotFound(w, "Please check your parameters")
		logobj.OutputData = "Please check your parameters"
		logobj.Process = "faild"
		logpkg.WriteOnlogFile(logobj)
		return
	}

	var flag bool
	for _, User := range userobjlst {
		if User.Confirmation_code == keys[0] {

			userObj = User
			flag = true
			break
		}
	}

	if flag != true {
		globalPkg.SendError(w, "please,check Your verification Code")
		logobj.OutputData = "please,check Your verification Code"
		logobj.Process = "faild"
		logpkg.WriteOnlogFile(logobj)
		return
	}
	if userObj.Confirmed == true {

		globalPkg.SendError(w, "user not login at first time yet")
		logobj.OutputData = "user not login at first time yet"
		logobj.Process = "faild"
		logpkg.WriteOnlogFile(logobj)
		return
	}

	if now.Sub(userObj.CurrentTime).Seconds() > globalPkg.GlobalObj.DeleteAccountTimeInseacond {

		globalPkg.SendError(w, "Time out")
		logobj.OutputData = "Time out"
		logobj.Process = "faild"
		logpkg.WriteOnlogFile(logobj)
		return

	}
	//userobjlst[index].Confirmed = true
	if userObj.Method == "POST" {
		fmt.Println("______________________________________________________________________________")
		userObj.Account.AccountInitialUserName = userObj.Account.AccountName
		userObj.Account.AccountInitialPassword = userObj.Account.AccountPassword
		userObj.Account.AccountIndex = newIndex()
		userObj.Confirmed = true
		broadcastTcp.BoardcastingTCP(userObj.Account, "POST", "account")
		//broadcastTcp.BoardcastingTCP(userObj, "Update", "account module")
		// UpdateconfirmAtribute(userObj)
	}

	// time, _ := time.Parse("2006-01-02 03:04:05 PM -0000", time.Now().UTC().Format("2006-01-02 03:04:05 PM -0000"))
	if userObj.Method == "PUT" {
		Message, _ := confirmationProcess(userObj, keys[0], userObj.CurrentTime)
		if Message != "" {
			http.Redirect(w, req, validator.DigitalWalletIpObj.DigitalwalletIp+":"+validator.DigitalWalletIpObj.Digitalwalletport+"/auth/register", http.StatusSeeOther)
			logobj.OutputData = Message
			logobj.Process = "faild"
			logpkg.WriteOnlogFile(logobj)

			return
		}

	}
	http.Redirect(w, req, validator.DigitalWalletIpObj.DigitalwalletIp+":"+validator.DigitalWalletIpObj.Digitalwalletport+"/auth/login", http.StatusSeeOther)
	logobj.OutputData = "redirect user to login page"
	logobj.Process = "success"
	logpkg.WriteOnlogFile(logobj)
}

//Login login End Point -------------------
//------------user can login to his Account using Email Or phone
//-----------and password
func Login(w http.ResponseWriter, req *http.Request) {

	now, _ := time.Parse("2006-01-02 03:04:05 PM -0000", time.Now().UTC().Format("2006-01-02 03:04:05 PM -0000"))

	ip, _, _ := net.SplitHostPort(req.RemoteAddr)
	userIP := net.ParseIP(ip)
	logobj := logpkg.LogStruct{now, userIP, "macAdress", "Login", "AccountModule", "", "", "_"}

	var NewloginUser = loginUser{}
	//	var SessionObj = SessionStruct{}
	var SessionObj session.AccountSessionStruct
	// err := json.NewDecoder(req.Body).Decode(&NewloginUser)
	// if err != nil {
	// 	logobj.OutputData = "Faild to read user object"
	// 	logobj.Process = "faild"
	// 	logpkg.WriteOnlogFile(logobj)
	// 	log.Printf("Failed unmarshaling : %s\n", err)

	// 	sendResponse(w, "Faild to read user object")
	// 	return
	// }
	decoder := json.NewDecoder(req.Body)
	decoder.DisallowUnknownFields()
	err := decoder.Decode(&NewloginUser)
	if err != nil {
		globalPkg.SendError(w, "please enter your correct request ")
		logobj.OutputData = "Faild to Decode Object"
		logobj.Process = "faild"
		logpkg.WriteOnlogFile(logobj)
		return
	}
	InputData := NewloginUser.EmailOrPhone + "," + NewloginUser.Password + "," + NewloginUser.AuthValue
	logobj.InputData = InputData
	//confirm email is lowercase and trim
	NewloginUser.EmailOrPhone = convertStringTolowerCaseAndtrimspace(NewloginUser.EmailOrPhone)
	if NewloginUser.EmailOrPhone == "" {
		logobj.OutputData = "please Enter your Email Or Phone"
		logobj.Process = "faild"
		logpkg.WriteOnlogFile(logobj)
		globalPkg.SendNotFound(w, "please Enter your Email Or Phone")
		return
	}
	if NewloginUser.AuthValue == "" && NewloginUser.Password == "" {
		logobj.OutputData = "please Enter your password  Or Authvalue"
		logobj.Process = "faild"
		logpkg.WriteOnlogFile(logobj)
		globalPkg.SendError(w, "please Enter your password  Or Authvalue")

		return

	}

	var accountObj AccountStruct
	//var accountObjByPhone AccountStruct
	var Email bool
	Email = false
	if strings.Contains(NewloginUser.EmailOrPhone, "@") && strings.Contains(NewloginUser.EmailOrPhone, ".") {
		Email = true
		accountObj = getAccountByEmail(NewloginUser.EmailOrPhone)
	} else {
		accountObj = getAccountByPhone(NewloginUser.EmailOrPhone)
	}

	if accountObj.AccountPublicKey == "" {
		var user User
		user = checkloginatFirst(NewloginUser.EmailOrPhone)
		user = createPublicAndPrivate(user)
		accountObj = convertUserTOAccount(user)
		sendJson, _ := json.Marshal(accountObj)
		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(http.StatusOK)
		w.Write(sendJson)

		if user.Account.AccountPublicKey != "" {
			SessionObj.SessionId = NewloginUser.SessionID
			SessionObj.AccountIndex = accountObj.AccountIndex
			//--search if sesssion found
			// session should be unique
			flag, _ := CheckIfsessionFound(SessionObj)
			fmt.Println("flaggggg", flag)
			if flag == true {
				fmt.Println("trueeeeeeeeeeeeee")
				//var SessionObj2 session.AccountSessionStruct
				//SessionObj2.AccountIndex = accountIndex
				broadcastTcp.BoardcastingTCP(SessionObj, "", "Delete Session")

			}
			broadcastTcp.BoardcastingTCP(SessionObj, "", "Add Session")
			// broadcastTcp.BoardcastingTCP(SessionObj, "", "Add Session")
			/////
			return
		}

	}

	if accountObj.AccountIndex == "" && Email == true { //AccountPublicKey replaces with AccountIndex
		logobj.OutputData = "Please,Check your account Email "
		logobj.Process = "faild"
		logpkg.WriteOnlogFile(logobj)
		globalPkg.SendNotFound(w, "Please,Check your account Email ")
		return
	}
	if accountObj.AccountPublicKey == "" && Email == false {
		logobj.OutputData = "Please,Check your account phone "
		logobj.Process = "faild"
		logpkg.WriteOnlogFile(logobj)
		globalPkg.SendNotFound(w, "Please,Check your account phone ")
		return
	}

	if (accountObj.AccountName == "" || (NewloginUser.Password != "" && accountObj.AccountPassword != NewloginUser.Password && Email == true) || (accountObj.AccountEmail != NewloginUser.EmailOrPhone && Email == true && NewloginUser.Password != "")) && NewloginUser.Password != "" {
		logobj.OutputData = "Please,Check your account Email or password"
		logobj.Process = "faild"
		logpkg.WriteOnlogFile(logobj)
		globalPkg.SendError(w, "Please,Check your account Email or password")

		return

	}
	if (accountObj.AccountName == "" || (accountObj.AccountAuthenticationValue != NewloginUser.AuthValue && Email == true) || (accountObj.AccountEmail != NewloginUser.EmailOrPhone && Email == true)) && NewloginUser.AuthValue != "" {
		logobj.OutputData = "Please,Check your account Email or AuthenticationValue"
		logobj.Process = "faild"
		logpkg.WriteOnlogFile(logobj)
		globalPkg.SendError(w, "Please,Check your account Email or AuthenticationValue")

		return

	}
	if (accountObj.AccountName == "" || (strings.TrimSpace(accountObj.AccountPhoneNumber) != "" && Email == false) || (accountObj.AccountPassword != NewloginUser.Password && Email == false) || (accountObj.AccountPhoneNumber != NewloginUser.EmailOrPhone && Email == false)) && NewloginUser.Password != "" {
		fmt.Println("i am a phone")
		logobj.OutputData = "Please,Check your account  phoneNAmber OR password"
		logobj.Process = "faild"
		logpkg.WriteOnlogFile(logobj)
		globalPkg.SendError(w, "Please,Check your account  phoneNAmber OR password")

		return

	}
	// SessionObj.SessionId = NewloginUser.SessionID
	// SessionObj.AccountID = accountObj.AccountIndex
	// //--search if sesssion found
	// // session should be unique
	// flag, _ := CheckIfsessionFound(SessionObj)
	// if flag == true {

	// 	broadcastTcp.BoardcastingTCP(SessionObj, "", "Delete Session")

	// 	//deleteSessionId(SessionObj)
	// 	fmt.Println("iam trueeeeeeeeeeeeee")
	// // }
	// SessionObj.SessionId = NewloginUser.SessionID
	// SessionObj.AccountIndex = accountObj.AccountIndex
	// //--search if sesssion found
	// // session should be unique
	// flag, _ := CheckIfsessionFound(SessionObj)
	// fmt.Println("flaggggg", flag)
	// if flag == true {
	// 	fmt.Println("trueeeeeeeeeeeeee")
	// 	//var SessionObj2 session.AccountSessionStruct
	// 	//SessionObj2.AccountIndex = accountIndex
	// 	broadcastTcp.BoardcastingTCP(SessionObj, "", "Delete Session")

	// }
	// broadcastTcp.BoardcastingTCP(SessionObj, "", "Add Session")
	// broadcastTcp.BoardcastingTCP(SessionObj, "", "Add Session")
	/////
	if (accountObj.AccountName == "" || (strings.TrimSpace(accountObj.AccountPhoneNumber) != "" && Email == false) || (accountObj.AccountPassword != NewloginUser.AuthValue && Email == false) || (accountObj.AccountPhoneNumber != NewloginUser.EmailOrPhone && Email == false)) && NewloginUser.AuthValue != "" {
		fmt.Println("i am a phone")
		logobj.OutputData = "Please,Check your account  phoneNAmber OR AuthenticationValue"
		logobj.Process = "faild"
		logpkg.WriteOnlogFile(logobj)

		globalPkg.SendError(w, "Please,Check your account  phoneNAmber OR AuthenticationValue")

		return

	}
	fmt.Println(accountObj)
	SessionObj.SessionId = NewloginUser.SessionID
	SessionObj.AccountIndex = accountObj.AccountIndex
	//--search if sesssion found
	// session should be unique
	flag, _ := CheckIfsessionFound(SessionObj)
	fmt.Println("flaggggg", flag)
	if flag == true {
		fmt.Println("trueeeeeeeeeeeeee")
		//var SessionObj2 session.AccountSessionStruct
		//SessionObj2.AccountIndex = accountIndex
		broadcastTcp.BoardcastingTCP(SessionObj, "", "Delete Session")

	}
	broadcastTcp.BoardcastingTCP(SessionObj, "", "Add Session")
	// broadcastTcp.BoardcastingTCP(SessionObj, "", "Add Session")
	/////
	logobj.OutputData = accountObj.AccountName + "," + accountObj.AccountPassword + "," + accountObj.AccountEmail + "," + accountObj.AccountRole
	logobj.Process = "success"
	logpkg.WriteOnlogFile(logobj)
	sendJson, _ := json.Marshal(accountObj)
	globalPkg.SendResponse(w, sendJson)

}

// func Login(w http.ResponseWriter, req *http.Request) {

// 	now, _ := time.Parse("2006-01-02 03:04:05 PM -0000", time.Now().UTC().Format("2006-01-02 03:04:05 PM -0000"))

// 	ip, _, _ := net.SplitHostPort(req.RemoteAddr)
// 	userIP := net.ParseIP(ip)
// 	logobj := logpkg.LogStruct{now, userIP, "macAdress", "Login", "AccountModule", "_", "_", "_"}

// 	var NewloginUser = loginUser{}
// 	var SessionObj = SessionStruct{}

// 	decoder := json.NewDecoder(req.Body)
// 	decoder.DisallowUnknownFields()
// 	err := decoder.Decode(&NewloginUser)
// 	if err != nil {
// 		globalPkg.SendError(w, "please enter your correct request ")
// 		logobj.OutputData = "Faild to Decode Object"
// 		logobj.Process = "faild"
// 		logpkg.WriteOnlogFile(logobj)
// 		return
// 	}
// 	InputData := NewloginUser.EmailOrPhone + "," + NewloginUser.Password + "," + NewloginUser.AuthValue
// 	logobj.InputData = InputData
// 	//confirm email is lowercase and trim
// 	NewloginUser.EmailOrPhone = convertStringTolowerCaseAndtrimspace(NewloginUser.EmailOrPhone)
// 	if NewloginUser.EmailOrPhone == "" {
// 		globalPkg.SendNotFound(w, "please Enter your Email Or Phone")
// 		logobj.OutputData = "please Enter your Email Or Phone"
// 		logobj.Process = "faild"
// 		logpkg.WriteOnlogFile(logobj)

// 		return
// 	}
// 	if NewloginUser.AuthValue == "" && NewloginUser.Password == "" {
// 		globalPkg.SendError(w, "please Enter your password  Or Authvalue")
// 		logobj.OutputData = "please Enter your password  Or Authvalue"
// 		logobj.Process = "faild"
// 		logpkg.WriteOnlogFile(logobj)
// 		return

// 	}
// 	if NewloginUser.SessionID == "" {
// 		globalPkg.SendError(w, "SessionID shouldn't be Null")
// 		logobj.OutputData = "SessionID shouldn't be Null"
// 		logobj.Process = "faild"
// 		logpkg.WriteOnlogFile(logobj)
// 		return

// 	}
// 	var accountObj AccountStruct
// 	//var accountObjByPhone AccountStruct
// 	var Email bool
// 	Email = false
// 	if strings.Contains(NewloginUser.EmailOrPhone, "@") && strings.Contains(NewloginUser.EmailOrPhone, ".") {
// 		fmt.Println("Iam Email")
// 		Email = true
// 		accountObj = getAccountByEmail(NewloginUser.EmailOrPhone)

// 	} else {
// 		accountObj = getAccountByPhone(NewloginUser.EmailOrPhone)
// 	}
// 	/////_________________________________
// 	//////check if user not confirm yet
// 	if accountObj.AccountPublicKey == "" {

// 		var user User

// 		user = checkloginatFirst(NewloginUser.EmailOrPhone)
// 		if user.PublicKey != "" && user.Password == NewloginUser.Password {
// 			accountObj = convertUserTOAccount(user)

// 			accountObj.AccountPrivateKey = ""
// 			broadcastTcp.BoardcastingTCP(accountObj, "POST", "account")

// 			accountObj.AccountPrivateKey = user.Privatekey
// 			accountObj.AccountPublicKey = user.PublicKey

// 			sendJson, _ := json.Marshal(accountObj)
// 			globalPkg.SendResponse(w, sendJson)

// 			logobj.OutputData = "login Successful"
// 			logobj.Process = "success"
// 			logpkg.WriteOnlogFile(logobj)
// 			return
// 		}

// 	}

// 	if accountObj.AccountPublicKey == "" && Email == true {
// 		globalPkg.SendNotFound(w, "Please,Check your account Email ")
// 		logobj.OutputData = "Please,Check your account Email "
// 		logobj.Process = "faild"
// 		logpkg.WriteOnlogFile(logobj)

// 		return
// 	}
// 	if accountObj.AccountPublicKey == "" && Email == false {
// 		globalPkg.SendNotFound(w, "Please,Check your account phone ")
// 		logobj.OutputData = "Please,Check your account phone "
// 		logobj.Process = "faild"
// 		logpkg.WriteOnlogFile(logobj)

// 		return
// 	}

// 	if (accountObj.AccountName == "" || (NewloginUser.Password != "" && accountObj.AccountPassword != NewloginUser.Password && Email == true) || (accountObj.AccountEmail != NewloginUser.EmailOrPhone && Email == true && NewloginUser.Password != "")) && NewloginUser.Password != "" {
// 		globalPkg.SendError(w, "Please,Check your account Email or password")
// 		logobj.OutputData = "Please,Check your account Email or password"
// 		logobj.Process = "faild"
// 		logpkg.WriteOnlogFile(logobj)
// 		return

// 	}
// 	if (accountObj.AccountName == "" || (accountObj.AccountAuthenticationValue != NewloginUser.AuthValue && Email == true) || (accountObj.AccountEmail != NewloginUser.EmailOrPhone && Email == true)) && NewloginUser.AuthValue != "" {
// 		globalPkg.SendError(w, "Please,Check your account Email or AuthenticationValue")
// 		logobj.OutputData = "Please,Check your account Email or AuthenticationValue"
// 		logobj.Process = "faild"
// 		logpkg.WriteOnlogFile(logobj)
// 		return
// 	}
// 	if (accountObj.AccountName == "" || (strings.TrimSpace(accountObj.AccountPhoneNumber) != "" && Email == false) || (accountObj.AccountPassword != NewloginUser.Password && Email == false) || (accountObj.AccountPhoneNumber != NewloginUser.EmailOrPhone && Email == false)) && NewloginUser.Password != "" {
// 		fmt.Println("i am a phone")
// 		globalPkg.SendError(w, "Please,Check your account  phoneNAmber OR password")
// 		logobj.OutputData = "Please,Check your account  phoneNAmber OR password"
// 		logobj.Process = "faild"
// 		logpkg.WriteOnlogFile(logobj)

// 		return

// 	}

// 	SessionObj.SessionId = NewloginUser.SessionID
// 	SessionObj.AccountID = accountObj.AccountIndex
// 	//--search if sesssion found
// 	// session should be unique
// 	flag, index := CheckIfsessionFound(SessionObj.SessionId, accountObj.AccountIndex)
// 	if flag == true {

// 		broadcastTcp.BoardcastingTCP(index, "", "Delete Session")
// 		deleteSessionId(accountObj.AccountIndex, SessionObj.SessionId)
// 		//	globalPkg.SendError(w, "change your sessionId")
// 		//return
// 	} //else {
// 	broadcastTcp.BoardcastingTCP(SessionObj, "", "Add Session")

// 	if (accountObj.AccountName == "" || (strings.TrimSpace(accountObj.AccountPhoneNumber) != "" && Email == false) || (accountObj.AccountPassword != NewloginUser.AuthValue && Email == false) || (accountObj.AccountPhoneNumber != NewloginUser.EmailOrPhone && Email == false)) && NewloginUser.AuthValue != "" {
// 		fmt.Println("i am a phone")
// 		globalPkg.SendError(w, "Please,Check your account  phoneNAmber OR AuthenticationValue")
// 		logobj.OutputData = "Please,Check your account  phoneNAmber OR AuthenticationValue"
// 		logobj.Process = "faild"
// 		logpkg.WriteOnlogFile(logobj)
// 		return

// 	}
// 	fmt.Println(accountObj)
// 	sendJson, _ := json.Marshal(accountObj)
// 	globalPkg.SendResponse(w, sendJson)
// 	logobj.OutputData = accountObj.AccountName + "," + accountObj.AccountPassword + "," + accountObj.AccountEmail + "," + accountObj.AccountRole
// 	logobj.Process = "success"
// 	logpkg.WriteOnlogFile(logobj)

// }

//GetSearchProperty search EndPoint ----user can search for  Any account pk using
///------userName or Email Or Phone
//-------response have userName and Public key
func GetSearchProperty(w http.ResponseWriter, req *http.Request) {
	user := User{}

	// err := json.NewDecoder(req.Body).Decode(&user)
	// if err != nil {
	// 	log.Printf("Failed unmarshaling : %s\n", err)

	// 	sendResponseError(w, "Faild to read user object")
	// 	return
	// }
	decoder := json.NewDecoder(req.Body)
	decoder.DisallowUnknownFields()
	err := decoder.Decode(&user)
	if err != nil {
		globalPkg.SendError(w, "please enter your correct request ")
		return
	}

	//approve name is lowercase
	user.Account.AccountEmail = convertStringTolowerCaseAndtrimspace(user.Account.AccountEmail)
	user.Account.AccountName = convertStringTolowerCaseAndtrimspace(user.Account.AccountName)
	user.TextSearch = convertStringTolowerCaseAndtrimspace(user.TextSearch)
	var accountObj AccountStruct
	if user.Account.AccountName != "" {
		accountObj = getAccountByName(user.Account.AccountName)
	}

	if accountObj.AccountName == "" || accountObj.AccountPassword != user.Account.AccountPassword {
		globalPkg.SendNotFound(w, "Please,Check your account user name and password")

		return
	}

	PublicKey := getPublicKeyUsingString(user.TextSearch)
	if PublicKey == "" {
		globalPkg.SendNotFound(w, "I canot find user using this property, enter anthor---*")
		return
	}
	accountBypk := findAccountByAccountPublicKey(PublicKey)
	if !accountBypk.AccountStatus {
		globalPkg.SendError(w, "This user is not active")
		return
	}

	//	key := cryptogrpghy.CreateSHA1(accountObj.AccountPublicKey)

	//Encryptedpubkey := cryptogrpghy.RSAENC(validator.CurrentValidator.ValidatorPublicKey, []byte(key))
	//Encrypteddata := cryptogrpghy.KeyEncrypt(key, PublicKey)
	//fmt.Println("hashedkey1", key)
	////////////////////////////////////////////////////////////////////////////////
	//-----Decryption
	//hashedkey := cryptogrpghy.RSADEC(validator.CurrentValidator.ValidatorPrivateKey, Encryptedpubkey)

	var SR searchResponse
	SR.PublicKey = PublicKey

	SR.UserName = accountBypk.AccountName

	sendJson, _ := json.Marshal(SR)

	globalPkg.SendResponse(w, sendJson)
	// sendResponse(w,PublicKey)
}

// func GetSearchProperty(w http.ResponseWriter, req *http.Request) {
// 	//log
// 	now, _ := time.Parse("2006-01-02 03:04:05 PM -0000", time.Now().UTC().Format("2006-01-02 03:04:05 PM -0000"))
// 	ip, _, _ := net.SplitHostPort(req.RemoteAddr)
// 	userIP := net.ParseIP(ip)
// 	logobj := logpkg.LogStruct{now, userIP, "macAdress", "GetSearchProperty", "AccountModule", "_", "_", "_"}

// 	user := User{}

// 	decoder := json.NewDecoder(req.Body)
// 	decoder.DisallowUnknownFields()
// 	err := decoder.Decode(&user)
// 	if err != nil {
// 		globalPkg.SendError(w, "please enter your correct request ")
// 		logobj.OutputData = "please enter your correct request"
// 		logobj.Process = "faild"
// 		logpkg.WriteOnlogFile(logobj)
// 		return
// 	}

// 	//approve name is lowercase
// 	user.Email = convertStringTolowerCaseAndtrimspace(user.Email)
// 	user.Name = convertStringTolowerCaseAndtrimspace(user.Name)
// 	user.TextSearch = convertStringTolowerCaseAndtrimspace(user.TextSearch)
// 	var accountObj AccountStruct
// 	if user.Name != "" {
// 		accountObj = getAccountByName(user.Name)
// 	}

// 	if accountObj.AccountName == "" || accountObj.AccountPassword != user.Password {
// 		globalPkg.SendNotFound(w, "Please,Check your account user name and password")
// 		logobj.OutputData = "Please,Check your account user name and password"
// 		logobj.Process = "faild"
// 		logpkg.WriteOnlogFile(logobj)
// 		return
// 	}

// 	PublicKey := getPublicKeyUsingString(user.TextSearch)
// 	if PublicKey == "" {
// 		globalPkg.SendNotFound(w, "I canot find user using this property, enter anthor---*")
// 		logobj.OutputData = "I canot find user using this property, enter anthor---*"
// 		logobj.Process = "faild"
// 		logpkg.WriteOnlogFile(logobj)
// 		return
// 	}
// 	accountBypk := findAccountByAccountPublicKey(PublicKey)
// 	if !accountBypk.AccountStatus {
// 		globalPkg.SendError(w, "This user is not active")
// 		logobj.OutputData = "This user is not active"
// 		logobj.Process = "faild"
// 		logpkg.WriteOnlogFile(logobj)
// 		return
// 	}
// 	var SR searchResponse
// 	SR.PublicKey = PublicKey
// 	SR.UserName = accountBypk.AccountName
// 	sendJson, _ := json.Marshal(SR)
// 	globalPkg.SendResponse(w, sendJson)
// 	logobj.OutputData = "search success and output the publickey and accountname with that account "
// 	logobj.Process = "success"
// 	logpkg.WriteOnlogFile(logobj)

// }

//ResetPassword user can reset his password
func ResetPassword(w http.ResponseWriter, req *http.Request) {
	//log
	now, _ := time.Parse("2006-01-02 03:04:05 PM -0000", time.Now().UTC().Format("2006-01-02 03:04:05 PM -0000"))
	ip, _, _ := net.SplitHostPort(req.RemoteAddr)
	userIP := net.ParseIP(ip)
	logobj := logpkg.LogStruct{now, userIP, "macAdress", "ResetPassword", "AccountModule", "_", "_", "_"}

	ResetPasswordDataObj := ResetPasswordData{}
	Data := ResetPasswordData{}
	decoder := json.NewDecoder(req.Body)
	decoder.DisallowUnknownFields()
	err := decoder.Decode(&ResetPasswordDataObj)
	if err != nil {
		globalPkg.SendError(w, "please enter your correct request ")
		logobj.OutputData = "please enter your correct request"
		logobj.Process = "faild"
		logpkg.WriteOnlogFile(logobj)

		return
	}

	//email is lowercase
	ResetPasswordDataObj.Email = convertStringTolowerCaseAndtrimspace(ResetPasswordDataObj.Email)
	var AccountObj AccountStruct
	i, found := checkifusercheckToResetPass(ResetPasswordDataObj)

	if found == false {
		globalPkg.SendNotFound(w, "invalid Data")
		logobj.OutputData = "invalid Data"
		logobj.Process = "faild"
		logpkg.WriteOnlogFile(logobj)
		return

	}
	/////----Data should be removed from list
	Data = resetPassReq[i]

	if len(ResetPasswordDataObj.Newpassword) != 64 {
		globalPkg.SendError(w, " invalid password length ")
		logobj.OutputData = "invalid password length "
		logobj.Process = "faild"
		logpkg.WriteOnlogFile(logobj)
		return
	}
	sub := now.Sub(Data.CurrentTime).Seconds()
	if sub > 3000 {
		globalPkg.SendError(w, "Time out ")
		logobj.OutputData = "Time out "
		logobj.Process = "faild"
		logpkg.WriteOnlogFile(logobj)
		return
	}
	//resetPassReq = append(resetPassReq[:i], resetPassReq[i+1:]...)
	//removeResetpassFromtemp(i)
	if ResetPasswordDataObj.Email != "" {
		AccountObj = getAccountByEmail(ResetPasswordDataObj.Email)
		AccountObj.AccountPassword = ResetPasswordDataObj.Newpassword
		// var l []string
		// l = append(l, AccountObj.AccountLastUpdatedTime.Format("2006-01-02 03:04:05 PM -0000"))
		broadcastTcp.BoardcastingTCP(AccountObj, "Resetpass", "account")
		//updateAccount(AccountObj)

		globalPkg.SendResponseMessage(w, "your password successfully changed")
		logobj.OutputData = "your password successfully changed"
		logobj.Process = "success"
		logpkg.WriteOnlogFile(logobj)
		return

	}

	if ResetPasswordDataObj.Phonnum != "" {
		AccountObj = getAccountByPhone(ResetPasswordDataObj.Email)
		AccountObj.AccountPassword = ResetPasswordDataObj.Newpassword

		broadcastTcp.BoardcastingTCP(AccountObj, "Resetpass", "account") //	updateAccount(AccountObj)
		globalPkg.SendResponseMessage(w, "your password successfully changed")
		logobj.OutputData = "your password successfully changed"
		logobj.Process = "success"
		logpkg.WriteOnlogFile(logobj)
		return

	}

}

//ForgetPassword End point------------------
////---------user can make Request For Remmeber the password
func ForgetPassword(w http.ResponseWriter, req *http.Request) {

	//log
	now, _ := time.Parse("2006-01-02 03:04:05 PM -0000", time.Now().UTC().Format("2006-01-02 03:04:05 PM -0000"))
	ip, _, _ := net.SplitHostPort(req.RemoteAddr)
	userIP := net.ParseIP(ip)
	logobj := logpkg.LogStruct{now, userIP, "macAdress", "ForgetPassword", "AccountModule", "_", "_", "_"}

	RandomCode := encodeToString(globalPkg.GlobalObj.MaxConfirmcode)
	current, _ := time.Parse("2006-01-02 03:04:05 PM -0000", time.Now().UTC().Format("2006-01-02 03:04:05 PM -0000"))
	Confirmation_code := RandomCode
	contact := contact{}
	decoder := json.NewDecoder(req.Body)
	decoder.DisallowUnknownFields()
	err := decoder.Decode(&contact)
	if err != nil {
		globalPkg.SendError(w, "please enter your correct request ")
		logobj.OutputData = "please enter your correct request"
		logobj.Process = "faild"
		logpkg.WriteOnlogFile(logobj)

		return
	}

	// ForgetPassword email is lowercase and trim
	contact.Email = convertStringTolowerCaseAndtrimspace(contact.Email)
	//contact := string(b)
	fmt.Println("test", contact)
	RP := ResetPasswordData{}
	RP.Code = Confirmation_code
	RP.CurrentTime = current
	accountObjbyEmail := getAccountByEmail(contact.Email)
	accountObjByPhone := getAccountByPhone(contact.Phonnum)

	if accountObjbyEmail.AccountPublicKey != "" && contact.Email != "" {

		RP.Email = contact.Email

		broadcastTcp.BoardcastingTCP(RP, "addRestPassword", "account module")
		//addResetpassObjInTemp(RP)
		sendEmail(Confirmation_code, contact.Email)
		globalPkg.SendResponseMessage(w, Confirmation_code)

		logobj.OutputData = "success send confirmation code" + Confirmation_code
		logobj.Process = "success"
		logpkg.WriteOnlogFile(logobj)
		return
	}

	if accountObjByPhone.AccountPublicKey != "" && contact.Phonnum != "" {

		RP.Phonnum = contact.Phonnum

		broadcastTcp.BoardcastingTCP(RP, "addRestPassword", "account module")
		//addResetpassObjInTemp(RP)
		send_SMS(contact.Phonnum, Confirmation_code)
		globalPkg.SendResponseMessage(w, Confirmation_code)

		logobj.OutputData = "success send confirmation code" + Confirmation_code
		logobj.Process = "success"
		logpkg.WriteOnlogFile(logobj)
		return
	}

	globalPkg.SendError(w, "invalid Email Or Phone")
	logobj.OutputData = "invalid Email Or Phone" + Confirmation_code
	logobj.Process = "fail"
	logpkg.WriteOnlogFile(logobj)

}

// DeleteSessionID endpoint to broadcast adding or deleting a transaction
func DeleteSessionID(w http.ResponseWriter, req *http.Request) {

	//log
	now, _ := time.Parse("2006-01-02 03:04:05 PM -0000", time.Now().UTC().Format("2006-01-02 03:04:05 PM -0000"))
	ip, _, _ := net.SplitHostPort(req.RemoteAddr)
	userIP := net.ParseIP(ip)
	logobj := logpkg.LogStruct{now, userIP, "macAdress", "DeleteSessionID", "AccountModule", "_", "_", "_"}

	// w.Header().Set("Content-Type", "application/json")
	var delObj DelSession
	// err := json.NewDecoder(req.Body).Decode(&delObj)

	decoder := json.NewDecoder(req.Body)
	decoder.DisallowUnknownFields()
	err := decoder.Decode(&delObj)
	errStr := ""
	if err != nil {
		errStr = errorpk.AddError("DeleteSessionID AccountModuleAPI  "+req.Method, "can't convert body to Transaction obj", "runtime error")
		globalPkg.SendError(w, "please enter your correct request ")
		logobj.OutputData = "please enter your correct request"
		logobj.Process = "faild"
		logpkg.WriteOnlogFile(logobj)
		return
	} else {
		account := GetAccountByIndex(delObj.AccounIndex)
		if account.AccountInitialPassword == delObj.Passord {
			//errStr still null and will call dellete seesion id in the next if condition
		} else {
			errStr = errorpk.AddError("DeleteSessionID AccountModuleAPI "+req.Method, "Wrong password and not authorized to delete this session!", "hack error")
		}
	}
	//var sessionobj SessionStruct
	var sessionobj session.AccountSessionStruct
	if errStr == "" {
		sessionobj.SessionId = delObj.SessionID
		sessionobj.AccountIndex = delObj.AccounIndex
		deleteSessionId(sessionobj)
		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(http.StatusOK)
	} else {
		// w.WriteHeader(http.StatusInternalServerError)
		// w.Write([]byte(errStr))

		globalPkg.SendError(w, errStr)
		logobj.OutputData = errStr
		logobj.Process = "fail"
		logpkg.WriteOnlogFile(logobj)
	}

}

func ServiceRegisterAPI(w http.ResponseWriter, req *http.Request) {
	logStruct := logpkg.LogStruct{}

	logStruct.Function = "serviceRegister"
	logStruct.Module = "account"

	userObj := User{}
	userObj.Method = "POST"
	decoder := json.NewDecoder(req.Body)
	decoder.DisallowUnknownFields()
	err := decoder.Decode(&userObj.Account)
	if err != nil {
		globalPkg.SendError(w, "please enter your correct request ")
		logStruct.OutputData = "Failed to Decode Object"
		logStruct.Process = "failed"
		logpkg.WriteOnlogFile(logStruct)
		return
	}
	InputData := userObj.Account.AccountName + "," + userObj.Account.AccountEmail + "," + userObj.Account.AccountPhoneNumber + userObj.Account.AccountPassword
	logStruct.InputData = InputData

	//check username and email is lowercase
	userObj.Account.AccountEmail = convertStringTolowerCaseAndtrimspace(userObj.Account.AccountEmail)
	userObj.Account.AccountName = convertStringTolowerCaseAndtrimspace(userObj.Account.AccountName)
	//check if account exist or Any field found before
	var Error string
	var accountStruct AccountStruct
	Error = userValidation(userObj)
	if Error != "" {
		globalPkg.SendError(w, Error)
		logStruct.Process = "faild"
		logStruct.OutputData = "error in validate user :" + Error + "\n"
		logpkg.WriteOnlogFile(logStruct)
		//sendResponse(w, Error)
		return
	}

	userObj.Account.AccountRole = "service"
	userObj.Account.AccountTokenID, _ = globalPkg.ConvertIntToFixedLengthString(2, globalPkg.GlobalObj.TokenIDStringFixedLength) // second token id
	userObj.Account.AccountInitialUserName = userObj.Account.AccountName
	userObj.Account.AccountInitialPassword = userObj.Account.AccountPassword
	userObj = createPublicAndPrivate(userObj)

	accountStruct = convertUserTOAccount(userObj)

	var current time.Time
	current, _ = time.Parse(time.RFC1123, time.Now().UTC().Format(time.RFC1123))

	userObj.CurrentTime = current
	broadcastTcp.BoardcastingTCP(accountStruct, "POST", "account")
	sendJson, _ := json.Marshal(accountStruct)
	globalPkg.SendResponse(w, sendJson)

	logStruct.Process = "success"
	logStruct.OutputData = "service successfully registered" + "\n"
	logpkg.WriteOnlogFile(logStruct)
}
func ServiceUpdateAPI(w http.ResponseWriter, req *http.Request) {
	now, _ := time.Parse(time.RFC1123, time.Now().UTC().Format(time.RFC1123))

	user := User{}
	user.Method = "PUT"
	//------------------ log file structure -------------------------------
	ip, _, _ := net.SplitHostPort(req.RemoteAddr)
	userIP := net.ParseIP(ip)
	logobj := logpkg.LogStruct{now, userIP, "macAdress", "UpdateAccountInfo", "AccountModule", "", "", "_"}
	decoder := json.NewDecoder(req.Body)
	decoder.DisallowUnknownFields()
	err := decoder.Decode(&user)
	if err != nil {
		globalPkg.SendError(w, "please enter your correct request ")
		logobj.OutputData = "Failed to Decode Object"
		logobj.Process = "failed"
		logpkg.WriteOnlogFile(logobj)
		return
	}
	InputData := user.Account.AccountName + "," + user.Account.AccountEmail + "," + user.Account.AccountPhoneNumber + user.Account.AccountPassword
	logobj.InputData = InputData

	//approve username & email is lowercase and trim
	user.Account.AccountEmail = convertStringTolowerCaseAndtrimspace(user.Account.AccountEmail)
	user.Account.AccountName = convertStringTolowerCaseAndtrimspace(user.Account.AccountName)

	var accountObj AccountStruct
	accountObj = findAccountByAccountPublicKey(user.Account.AccountPublicKey)
	if accountObj.AccountPassword != user.Oldpassword {
		globalPkg.SendError(w, "Invalid Password")
		logobj.OutputData = "Invalid Password"
		logobj.Process = "failed"
		logpkg.WriteOnlogFile(logobj)
		return
	}
	//check if account exist
	var accountStruct AccountStruct

	accountStruct = convertUserTOAccount(user)

	// MessageErr := checkingIfAccountExixtsBeforeUpdating(accountStruct)
	// if MessageErr != "" {
	// 	globalPkg.SendNotFound(w, MessageErr)
	// 	logobj.OutputData = MessageErr
	// 	logobj.Process = "failed"
	// 	logpkg.WriteOnlogFile(logobj)
	// 	return
	// }

	// current, _ := time.Parse("2006-01-02 03:04:05 PM -0000", time.Now().UTC().Format("2006-01-02 03:04:05 PM -0000"))
	current, _ := time.Parse(time.RFC1123, time.Now().UTC().Format(time.RFC1123))
	user.CurrentTime = current

	//	updatedaccountobj := convertUserTOAccount(userobject)
	accountObj.AccountName = accountStruct.AccountName
	accountObj.AccountPassword = accountStruct.AccountPassword
	accountObj.AccountPhoneNumber = accountStruct.AccountPhoneNumber
	accountObj.AccountAddress = accountStruct.AccountAddress
	accountObj.AccountEmail = accountStruct.AccountEmail
	//accountobj.AccountPublicKey = accountStruct.AccountPublicKey
	accountObj.AccountRole = "service"
	// var lst []string
	// lst = append(lst, accountObj.AccountLastUpdatedTime.Format("2006-01-02 03:04:05 PM -0000"))
	broadcastTcp.BoardcastingTCP(accountObj, "PUT", "account")
	// broadcastTcp.BoardcastingTCP(accountObj, validator.CurrentValidator.ValidatorPublicKey, "PUT", "account", lst)
	tempAcc := accountObj
	tempAcc.AccountInitialUserName = ""
	tempAcc.AccountInitialPassword = ""
	tempAcc.AccountRole = ""
	tempAcc.AccountLastUpdatedTime = time.Time{}
	tempAcc.AccountBalance = ""
	tempAcc.BlocksLst = nil
	tempAcc.SessionID = ""

	sendJson, _ := json.Marshal(tempAcc)
	globalPkg.SendResponse(w, sendJson)

	logobj.OutputData = accountObj.AccountName + "Update success"
	logobj.Process = "success"
	logpkg.WriteOnlogFile(logobj)

}

//SavePublickey api called when user saves his private key
func SavePublickey(w http.ResponseWriter, req *http.Request) {
	//log
	now, _ := time.Parse("2006-01-02 03:04:05 PM -0000", time.Now().UTC().Format("2006-01-02 03:04:05 PM -0000"))
	ip, _, _ := net.SplitHostPort(req.RemoteAddr)
	userIP := net.ParseIP(ip)
	logobj := logpkg.LogStruct{now, userIP, "macAdress", "DeleteSessionID", "AccountModule", "_", "_", "_"}

	var saveKeyReq savekey
	decoder := json.NewDecoder(req.Body)
	decoder.DisallowUnknownFields()
	err := decoder.Decode(&saveKeyReq)
	errStr := ""
	if err != nil {
		errStr = errorpk.AddError("SavePublickey AccountModuleAPI  "+req.Method, "can't convert body to saveKeyReq obj", "runtime error")
		globalPkg.SendError(w, "please enter your correct request make sure that your req contain : Publickey then Password then Email ")
		logobj.OutputData = "please enter your correct request"
		logobj.Process = "faild"
		logpkg.WriteOnlogFile(logobj)
		return
	}
	account := getAccountByEmail(saveKeyReq.Email)
	if account.AccountEmail == saveKeyReq.Email && account.AccountPassword == saveKeyReq.Passsword {
		account.AccountPublicKey = saveKeyReq.PublicKey
		broadcastTcp.BoardcastingTCP(account, "set public key", "account")
	} else {
		globalPkg.SendError(w, "failed to get this email plz check if account exist an make sure to insert the right pass and email!")
		logobj.OutputData = "failed to get this email plz check if account exist an make sure to insert the right pass and email!"
		logobj.Process = "fail"
		logpkg.WriteOnlogFile(logobj)
	}
	// broadcastTcp.BoardcastingTCP(account, "set public key", "account")
	if errStr == "" {
		sendJson, _ := json.Marshal(account)
		globalPkg.SendResponse(w, sendJson)
		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(http.StatusOK)
	} else {
		globalPkg.SendError(w, errStr)
		logobj.OutputData = errStr
		logobj.Process = "fail"
		logpkg.WriteOnlogFile(logobj)
	}

}
