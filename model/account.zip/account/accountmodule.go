package account

import (
	"crypto/rand"
	"crypto/sha1"
	"encoding/base64"
	"fmt"
	"strconv"

	session "../session"

	//"../cryptogrpghy"
	"net/smtp"
	"rsapk"

	// "rsapk"
	"strings"

	"io"

	"../broadcastTcp"

	cryptogrpghy "../cryptogrpghy"
	"../errorpk"
	"../globalPkg"
	"../validator"

	"log"
	mathrand "math/rand"

	"time"

	nexmo "gopkg.in/njern/gonexmo.v2" /////Api  to send SMS
)

type contact struct {
	Email       string
	Phonnum     string
	CurrentTime time.Time
}
type stringmessage struct {
	Message string
}
type errorMess struct {
	ErrorMessage string
}

// type User struct {
// 	Name                string
// 	Email               string
// 	Phonnum             string
// 	Address             string
// 	AuthenticationType  string
// 	AuthenticationValue string
// 	Password            string
// 	Oldpassword         string
// 	Role                string
// 	Reson               string
// 	CurrentTime         time.Time
// 	PublicKey           string
// 	Privatekey          string
// 	InitialName         string
// 	InitialPassword     string
// 	Index               string
// 	Confirmation_code   string
// 	TextSearch          string
// 	Method              string
// 	Balance             string
// 	Confirmed           bool

// 	FirstTime bool ////first time to login

// }
type User struct {
	Account           AccountStruct
	Oldpassword       string
	Reson             string
	CurrentTime       time.Time
	Confirmation_code string
	TextSearch        string
	Method            string
	Confirmed         bool
	FirstTime         bool // first time to login
}

type searchResponse struct {
	UserName  string
	PublicKey string
}
type ResetPasswordData struct {
	Code        string
	Email       string
	Phonnum     string
	Newpassword string
	CurrentTime time.Time
}
type loginUser struct {
	EmailOrPhone string
	Password     string
	SessionID    string
	AuthValue    string
}
type SessionStruct struct {
	SessionId string
	Time      time.Time
	AccountID string
}

type deactivateInfo struct {
	PublicKey          string
	DeactivationReason string
	UserName           string
	Password           string
}
type cryptoData struct {
	PublicKey  string
	PrivateKey string
}

var userobjlst []User
var sessionslst []SessionStruct

//----------array hava All requests to reset paasword which not
//-----confirmed yet
var resetPassReq []ResetPasswordData
var randomTable = [...]byte{'1', '2', '3', '4', '5', '6', '7', '8', '9', '0'}

func SetUserObjLst(userObjLst []User) {
	userobjlst = userObjLst
}
func GetUserObjLst() []User {
	return userobjlst
}
func SetResetPasswordData(resetPasswordDataObj []ResetPasswordData) {
	resetPassReq = resetPasswordDataObj
}
func GetResetPasswordData() []ResetPasswordData {
	return resetPassReq
}

//convertStringTolowerCaseAndtrimspace approve username , email is lowercase and trim spaces
func convertStringTolowerCaseAndtrimspace(stringphrase string) string {
	stringphrase = strings.ToLower(stringphrase)
	stringphrase = strings.TrimSpace(stringphrase)
	return stringphrase

}

//----------to convert User Object to Account Object----
func convertUserTOAccount(userObj User) AccountStruct {
	userObj.Account.AccountLastUpdatedTime, _ = time.Parse("2006-01-02 03:04:05 PM -0000", time.Now().UTC().Format("2006-01-02 03:04:05 PM -0000"))

	if userObj.Method == "POST" {
		userObj.Account.AccountInitialUserName = userObj.Account.AccountName
		userObj.Account.AccountInitialPassword = userObj.Account.AccountPassword
	}

	return userObj.Account
}

//------------clear User After 5 minite from Registration
func ClearDeadUser() {
	for {
		time.Sleep(time.Second * time.Duration(mathrand.Int31n(globalPkg.GlobalObj.DeleteAccountLoopTimeInseacond)))

		t, _ := time.Parse("2006-01-02 03:04:05 PM -0000", time.Now().UTC().Format("2006-01-02 03:04:05 PM -0000"))
		// t,_:=time.Parse("2006-01-02 03:04:05 PM -0000", time.Now().Format("2006-01-02 03:04:05 PM -0000"))
		//	fmt.Println("************",t)

		for index, userObj := range userobjlst {
			t2, _ := time.Parse("2006-01-02 03:04:05 PM -0000", userObj.CurrentTime.Format("2006-01-02 03:04:05 PM -0000"))
			Subtime := (t.Sub(t2)).Seconds()
			if Subtime > globalPkg.GlobalObj.DeleteAccountTimeInseacond { ///globalPkg.GlobalObj.DeleteAccountTimeInseacond {
				//userobjlst = append(userobjlst[:index], userobjlst[index+1:]...)
				fmt.Println(userObj.CurrentTime)
				fmt.Println("subbbbbb", Subtime)
				removeUserFromtemp(index)
			}

		}
		for index, userObj := range resetPassReq {
			t2, _ := time.Parse("2006-01-02 03:04:05 PM -0000", userObj.CurrentTime.Format("2006-01-02 03:04:05 PM -0000"))
			if t.Sub(t2).Seconds() > globalPkg.GlobalObj.DeleteAccountTimeInseacond { ////globalPkg.GlobalObj.DeleteAccountTimeInseacond
				removeResetpassFromtemp(index)
				//resetPassReq = append(resetPassReq[:index], resetPassReq[index+1:]...)

			}

		}

	}
}

//---------------send SMS Using nexmo API
func send_SMS(Phone_Number string, confirmation_code string) bool {

	nexmoClient, _ := nexmo.NewClient("53db0133", "iW59RoOYLrUBQ8yZ")

	// Test if it works by retrieving your account balance
	balance, err := nexmoClient.Account.GetBalance()
	log.Println(balance)
	message := &nexmo.SMSMessage{
		From: "go-nexmo",
		To:   Phone_Number,
		Type: nexmo.Text,
		Text: "Wellcom at your Wallet,your verfy code is: " + confirmation_code,
	}

	messageResponse, err := nexmoClient.SMS.Send(message)
	if err != nil {
		return false
	}

	log.Println("messageResponse: ", messageResponse)
	/*if messageResponse == "[{ "+ Phone_Number+"     Non White-listed Destination - rejected}]"{

	return false
	}*/
	log.Println("ERRRRROR :", err)
	return true
}

////////////////////////////////////////////////////////////
///---------send confirmation Email using Stmp
func sendEmail(Body string, Email string) {
	//mime := "MIME-version: 1.0;\nContent-Type: text/html; charset=\"UTF-8\";\n\n";
	from := "noreply@inovatian.com" ///// "inovatian.tech@gmail.com"
	pass := "ino13579$"             /////your passward   ////

	to := Email //Email of User

	msg := "From: " + from + "\n" +
		"To: " + to + "\n" +
		"Subject: Inovatian Digital Wallet Verification\n\n" + Body

	///confirmation link

	err := smtp.SendMail("mail.inovatian.com:26",
		smtp.PlainAuth("", from, pass, "mail.inovatian.com"),
		from, []string{to}, []byte(msg))

	if err != nil {
		log.Printf("smtp error: %s", err)
		return
	}

	log.Println("sent, visit", Email)
}

/*****send mail or SMS***/
func sendConfirmationEmailORSMS(userObj User) string {

	if userObj.Account.AccountEmail == "" {

		flag := send_SMS(userObj.Account.AccountPhoneNumber, userObj.Confirmation_code)
		if !flag {

			//
			return "sms not send NO internet connection"
		}

	} else {

		body := "Dear " + userObj.Account.AccountName + `,
Thank you for joining Inovatian’s InoChain, your request has been processed and your wallet has been created successfully.
Your confirmation code is: ` + userObj.Confirmation_code + `
Please follow the following link to activate your wallet:
(If this link is not clickable, please copy and paste into a new browser) 
` +
			validator.CurrentValidator.ValidatorIP + "/819c7f06486287e0a6c25f00?confirmationcode=" + userObj.Confirmation_code +
			`
This is a no-reply email; for any enquiries please contact info@inovatian.com
If you did not create this wallet, please disregard this email.
Regards,
Inovatian Team`
		sendEmail(body, userObj.Account.AccountEmail)

	}
	return ""
}

// ------Make random string code that i use it to Verify User
func encodeToString(max int) string {
	buffer := make([]byte, max)
	_, err := io.ReadAtLeast(rand.Reader, buffer, max)
	if err != nil {
		errorpk.AddError("account encodeToString", "the string is more than the max", "runtime error")
	}
	// for index := 0; index < len(buffer); index++ {
	// 	buffer[index] = randomTable[int(buffer[index])%len(randomTable)]
	// }

code:
	for index := 0; index < len(buffer); index++ {
		buffer[index] = randomTable[int(buffer[index])%len(randomTable)]
	}
	for _, userObj := range userobjlst {
		if userObj.Confirmation_code == string(buffer) {
			goto code
		}
	}
	return string(buffer)
}

//-----------TO CHECK iF USER rEGISTER AND NOT CONFIRMED
//----------oR USER REQUEST TO UPDATE HIS aCCCOUNT
//----------AND NOT CONFIRMED YET
func checkFoundInUserList(user User) (int, string) { //check if user found in userobj list

	var errorfound string
	errorfound = ""
	var index int
	index = -1
	for i, UserObj := range userobjlst {
		if UserObj.Account.AccountName == user.Account.AccountName && UserObj.Account.AccountEmail == user.Account.AccountEmail && UserObj.Account.AccountPhoneNumber == user.Account.AccountPhoneNumber && UserObj.Method == "POST" {
			errorfound = "this user  registered and not confirmed"
			index = -2
			break
		}
		if UserObj.Account.AccountName == user.Account.AccountName && UserObj.Account.AccountEmail == user.Account.AccountEmail && UserObj.Account.AccountPhoneNumber == user.Account.AccountPhoneNumber && UserObj.Method == "PUT" {
			errorfound = "user  Found"
			index = i
			break
		}
		if UserObj.Account.AccountEmail == user.Account.AccountEmail && user.Account.AccountEmail != "" && UserObj.Method == "POST" {
			errorfound = "this email registered and not confirmed"
			index = -2
			break
		}

		if UserObj.Account.AccountPhoneNumber == user.Account.AccountPhoneNumber && user.Account.AccountPhoneNumber != "" && UserObj.Method == "POST" {
			errorfound = "this phon registered and not confirmed"
			index = -2
			break
		}
		if UserObj.Account.AccountName == user.Account.AccountName && UserObj.Method == "POST" {
			errorfound = "this userName  registered and not confirmed"
			index = -2
			break
		}

		if UserObj.Account.AccountName == user.Account.AccountName && UserObj.Method == "PUT" {
			errorfound = "UserName Found"
			index = i
			break
		}
		if UserObj.Account.AccountEmail == user.Account.AccountEmail && user.Account.AccountEmail != "" && UserObj.Method == "PUT" {
			errorfound = "Email found"
			index = i
			break
		}
		if UserObj.Account.AccountPhoneNumber == user.Account.AccountPhoneNumber && user.Account.AccountPhoneNumber != "" && UserObj.Method == "PUT" {
			errorfound = "Phone Found "
			index = i
			break
		}

	}
	return index, errorfound
}

///////----
//--------to add User in userobj list
func AddUserIntemp(userobj User) {
	fmt.Println(userobj)
	userobjlst = append(userobjlst, userobj)
	fmt.Println("resetPassReq", userobjlst)

}

/////////////////////////////////////

//-------------Add Update Pass REq to Array
func AddResetpassObjInTemp(ResetpassObj ResetPasswordData) {

	resetPassReq = append(resetPassReq, ResetpassObj)

}

////////////////////////
//--------------remove User
func removeUserFromtemp(index int) {
	userobjlst = append(userobjlst[:index], userobjlst[index+1:]...)
}

func RemoveUserFromtemp(index int) {
	userobjlst = append(userobjlst[:index], userobjlst[index+1:]...)
}
func RemoveResetpassFromtemp(index int) {

	resetPassReq = append(resetPassReq[:index], resetPassReq[index+1:]...)

}

/////////////////////////////////////////////
//--------------------
func removeResetpassFromtemp(index int) {

	resetPassReq = append(resetPassReq[:index], resetPassReq[index+1:]...)

}

// //UpdateUserTotemp for update and reset password ---->isra
// func UpdateUserTotemp(index int,userobj User) {
// 	userobjlst = append(userobjlst[:index], userobjlst[index+1:]...)
// 	userobjlst = append(userobjlst, userobj)
// }
//UpdateResetpassObjInTemp for reset password ---->
func UpdateResetpassObjInTemp(index int, ResetpassObj ResetPasswordData) {
	resetPassReq = append(resetPassReq[:index], resetPassReq[index+1:]...)
	resetPassReq = append(resetPassReq, ResetpassObj)
}

//-------CHECK IF USER mAKE rEQUEST BEFORE TO RESET HIS PASSWORD-----
//----------------
func checkifusercheckToResetPass(userResetpass ResetPasswordData) (int, bool) { //check if User found in userobj list

	var errorfound bool
	var index int
	index = -1
	for i, U := range resetPassReq {

		if U.Email == userResetpass.Email && userResetpass.Email != "" && U.Code == userResetpass.Code {
			errorfound = true
			index = i
			break
		}
		if U.Phonnum == userResetpass.Phonnum && userResetpass.Phonnum != "" && U.Code == userResetpass.Code {
			errorfound = true
			index = i
			break
		}

		errorfound = false

	}
	return index, errorfound

}

//-----TO MAKE PROCESS Hapened in both confirmation Api
//------check if confirmation code valid
//------if invalid the func return please check your varification code
//------if User.Method ==post this mean that User confirm to register
//-----then we create public and private key and pass User to func AddAccount
//---if User.Method ==put thise mean that User confirm to update his info
//--then we pass the User account to UpdateAccount func

func confirmationProcess(userobject User, confirmationcode string, now time.Time) (string, User) {
	var flag bool
	//var userResult    User
	flag = false
	for _, User := range userobjlst {
		if User.Confirmation_code == confirmationcode {
			userobject = User

			flag = true

			break
		}

	}

	if flag != true {

		return "please,check Your verification Code", userobject
	}

	if now.Sub(userobject.CurrentTime).Seconds() > 3000.0 {
		return "Time out ", userobject
	}

	if userobject.Method == "POST" {
		var accountobj AccountStruct
		//////////////////create public and private key
		userobject.Account.AccountInitialUserName = userobject.Account.AccountName
		userobject.Account.AccountInitialPassword = userobject.Account.AccountPassword
		userobject.Account.AccountStatus = true
		userobject = createPublicAndPrivate(userobject)
		accountobj = convertUserTOAccount(userobject)
		accountobj.AccountPrivateKey = ""
		// var lst []string
		// lst = append(lst, accountobj.AccountLastUpdatedTime.Format("2006-01-02 03:04:05 PM -0000"))
		// broadcastTcp.BoardcastingTCP(accountobj, validator.CurrentValidator.ValidatorPublicKey, "POST", "account", lst)
		broadcastTcp.BoardcastingTCP(accountobj, "POST", "account")
		accountobj.AccountPrivateKey = userobject.Account.AccountPrivateKey
		//} else {
		//	return strErr
		//}
	}

	if userobject.Method == "PUT" {
		var accountobj AccountStruct

		accountobj = findAccountByAccountPublicKey(userobject.Account.AccountPublicKey)
		if accountobj.AccountPublicKey == "" {

			return "i canot find object iusing this PK", userobject
		}
		updatedaccountobj := convertUserTOAccount(userobject)

		accountobj.AccountName = updatedaccountobj.AccountName
		accountobj.AccountPassword = updatedaccountobj.AccountPassword
		accountobj.AccountPhoneNumber = updatedaccountobj.AccountPhoneNumber
		accountobj.AccountAddress = updatedaccountobj.AccountAddress
		accountobj.AccountEmail = updatedaccountobj.AccountEmail
		accountobj.AccountPublicKey = updatedaccountobj.AccountPublicKey

		//	broadcastTcp.BoardcastingTCP(accountobj, "POST", "account")
		//
		broadcastTcp.BoardcastingTCP(accountobj, "PUT", "account")
		fmt.Println("iam update-----------------______") //updateAccount(accountobj)

	}
	return "", userobject
}

//-----validate if User Enter Data valid
//-------then check if User exist before
func userValidation(userObj User) string {
	accountStruct := convertUserTOAccount(userObj)
	var MessageErr string
	if userObj.Method == "POST" {
		MessageErr = checkingIfAccountExixtsBeforeRegister(accountStruct)
	}
	if userObj.Method == "PUT" {
		MessageErr = checkingIfAccountExixtsBeforeUpdating(accountStruct)

	}

	if MessageErr != "" {

		return MessageErr
	}
	_, found := checkFoundInUserList(userObj)

	if found != "" {

		return found
	}
	return ""
}

//////////////////-----using in broadcast
//--------to broadcast Any User to All validator
func newUserBroadCast(userObj User) string {
	Error := userValidation(userObj)
	if Error != "" {
		return Error
	}
	////-------------goto Broad cast function ----//////
	return "Success"

}

func checkloginatFirst(contact string) User {

	var userobjResult User //---New
	//var cryptoDataObj cryptoDatavar index int
	for _, userobj := range userobjlst {
		if (userobj.Account.AccountEmail == contact && userobj.Account.AccountEmail != "" && userobj.Confirmed == true) || (userobj.Account.AccountPhoneNumber == contact && userobj.Account.AccountPhoneNumber != "" && userobj.Confirmed == true) {
			fmt.Println("///////", userobj.Confirmed)
			userobj = createPublicAndPrivate(userobj)

			return userobj

		}
	}

	return userobjResult //---New

}

////////////////////////////////////////////////////////////
//---------

func createPublicAndPrivate(userobj User) User {

	LastIndex := getLastIndex()
	index := 0
	if LastIndex != "-1" {
		// TODO : split LastIndex
		res := strings.Split(LastIndex, "_")
		if len(res) == 2 {
			index = globalPkg.ConvertFixedLengthStringtoInt(res[1]) + 1
		} else {
			index = globalPkg.ConvertFixedLengthStringtoInt(LastIndex) + 1
		}
	}
	userobj.Account.AccountIndex, _ = globalPkg.ConvertIntToFixedLengthString(index, globalPkg.GlobalObj.StringFixedLength)
	i, _ := strconv.Atoi(userobj.Account.AccountIndex)
	var currentIndex = ""
	if i > 0 {
		currentIndex = getHash([]byte(validator.CurrentValidator.ValidatorIP)) + "_" + userobj.Account.AccountIndex
	} else {
		currentIndex = userobj.Account.AccountIndex
	}

	log.Println("current index ", currentIndex)
	userobj.Account.AccountIndex = currentIndex
	bitSize := 1024
	reader := rand.Reader

	//infinite loop to get unique public key
	for {
		key, err := rsapk.GenerateKey(reader, bitSize)
		cryptogrpghy.CheckError(err)
		pk := cryptogrpghy.GetPublicPEMKey(key.PublicKey)
		var accountobj AccountStruct

		accountobj = GetAccountByAccountPubicKey(pk)
		if accountobj.AccountPublicKey == "" { //not found this public key in account DB
			userobj.Account.AccountPrivateKey = cryptogrpghy.GetPrivatePEMKey(key)
			userobj.Account.AccountPublicKey = cryptogrpghy.GetPublicPEMKey(key.PublicKey)
			break
		}
	}

	return userobj

}
func getHash(str []byte) string {
	hasher := sha1.New()
	hasher.Write(str)
	sha := base64.URLEncoding.EncodeToString(hasher.Sum(nil))
	return sha
}

///----------func to check if user first time login
///////////////////////////////////////////////////////////
/////////-------------update objList Array---------------------------------
func UpdateconfirmAtribute(userobj User) {
	var found bool
	var user User
	var index int

	for index, user = range userobjlst {
		if user.Confirmation_code == userobj.Confirmation_code {
			found = true
			userobjlst[index].Confirmed = true
			break
		}
	}
	if found == true {
		//var lst []string
		//lst = append(lst, user.CurrentTime.Format("2006-01-02 03:04:05 PM -0000"))
		// broadcastTcp.BoardcastingTCP(user, "Update", "account module")
	}
}

/////////////////////////////////////////////////////////
func CheckIfsessionFound(sessionstruct session.AccountSessionStruct) (bool, string) {

	acc := session.FindSessionByKey(sessionstruct.SessionId)
	if acc.SessionId != "" && acc.AccountIndex != sessionstruct.AccountIndex {

		return true, acc.AccountIndex

	} else {
		return false, ""
	}

}

//////////////////
//Add session
///

func AddSessioninTemp(sessionId session.AccountSessionStruct) {

	//sessionslst = append(sessionslst, sessionId)
	session.AddSessionIdStruct(sessionId)
	AddSession(sessionId.AccountIndex, sessionId.SessionId)

}

// func AddSessioninTemp(sessionId SessionStruct) {

// 	sessionslst = append(sessionslst, sessionId)
// 	AddSession(sessionId.AccountID, sessionId.SessionId)

// }
func AddSession(accountIndex string, sessionId string) {

	accountobj := GetAccountByIndex(accountIndex)
	accountobj.SessionID = sessionId
	UpdateAccount2(accountobj) ///new22
	//	broadcastTcp.BoardcastingTCP(accountobj, validator.CurrentValidator.ValidatorPublicKey, "PUT", "account", nil)

}

func Getaccountsessionid(publickey string) string {
	accountobj := GetAccountByAccountPubicKey(publickey)
	return accountobj.SessionID
}

// func Getaccountsessionid(publickey string) []string {
// 	accountobj := GetAccountByAccountPubicKey(publickey)
// 	arr := accountobj.SessionID
// 	return arr
// }
// func RemoveSessionFromtemp(index int) {
// 	sessionslst = append(sessionslst[:index], sessionslst[index+1:]...)
// }

//UpdateUserTotemp for update and reset password ---->isra
func UpdateUserTotemp(index int, userobj User) {
	userobjlst = append(userobjlst[:index], userobjlst[index+1:]...)
	userobjlst = append(userobjlst, userobj)
}

// func deleteSessionId(sessionobj SessionStruct) {

// 	accountobj := getAccountByIndex(sessionobj.AccountID)
// 	//	for index, sessionobj := range account.SessionID {

// 	if accountobj.SessionID == sessionobj.SessionId {

// 		accountobj.SessionID = ""
// 		//lst := append(lst, accountobj.AccountLastUpdatedTime.Format("2006-01-02 03:04:05 PM -0000"))
// 		fmt.Println("aaaaaasssss1", accountobj)
// 		UpdateAccount(accountobj)
// 		fmt.Println("aaaaaasssss2", accountobj)
// 		//broadcastTcp.BoardcastingTCP(accountobj, validator.CurrentValidator.ValidatorPublicKey, "PUT", "account", nil)

// 	}

// 	//}

// }

////////////////
// func RemoveSessionFromtemp(sessionstruct SessionStruct) {
// 	var Delsession SessionStruct
// 	fmt.Println("sessionlist1", sessionslst)
// 	for index, sessionobj := range sessionslst {

// 		if sessionobj.SessionId == sessionstruct.SessionId && sessionobj.AccountID != sessionstruct.AccountID {
// 			Delsession.AccountID = sessionobj.AccountID
// 			Delsession.SessionId = sessionobj.SessionId
// 			sessionslst = append(sessionslst[:index], sessionslst[index+1:]...)
// 			fmt.Println("sessionlist2", sessionslst)
// 			break
// 		}

// 	}

// 	deleteSessionId(Delsession)
// }
func RemoveSessionFromtemp(sessionstruct session.AccountSessionStruct) {
	var Delsession session.AccountSessionStruct

	Delsession = session.FindSessionByKey(sessionstruct.SessionId)
	session.DeleteSession(sessionstruct.SessionId)

	deleteSessionId(Delsession)
}
func deleteSessionId(sessionobj session.AccountSessionStruct) {

	accountobj := GetAccountByIndex(sessionobj.AccountIndex)

	fmt.Println("accountupdated1", accountobj)
	if accountobj.SessionID == sessionobj.SessionId {

		accountobj.SessionID = ""

		UpdateAccount2(accountobj)
		fmt.Println("accountupdated", accountobj)

	}

}
