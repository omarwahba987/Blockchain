package account

import (
	"fmt"
	"regexp"

	error "../errorpk"
	//globalPkg "github.com/tensor-programming/mining/../globalPkg"
)

/*----------------- function to get Account by public key -----------------*/
func GetAccountByAccountPubicKey(AccountPublicKey string) AccountStruct {
	return findAccountByAccountPublicKey(AccountPublicKey)
}

/*----------------- function to check if account exists or not -----------------*/
func ifAccountExistsBefore(AccountPublicKey string) bool {
	if (findAccountByAccountPublicKey(AccountPublicKey)).AccountPublicKey == "" {
		return false ////not exist
	}
	return true
}

/*----------------- function to save an account on json file -----------------*/
func AddAccount(accountObj AccountStruct) string {

	if !(ifAccountExistsBefore(accountObj.AccountPublicKey)) && validateAccount(accountObj) {
		if accountCreate(accountObj) {
			return ""
		} else {
			return error.AddError("AddAccount account package", "Check your path or object to Add AccountStruct", "logical error")
		}
	}
	return error.AddError("AddAccount account package", "The account is already exists "+accountObj.AccountPublicKey, "hack error")

}

func getLastIndex() string {

	var Account AccountStruct
	Account = getLastAccount()
	if Account.AccountPublicKey == "" {
		return "-1"
	}

	return Account.AccountIndex

}

/*----------------- function to update an account on json file -----------------*/
func UpdateAccount(accountObj AccountStruct) string {
	if (ifAccountExistsBefore(accountObj.AccountPublicKey)) && validateAccount(accountObj) {
		fmt.Println("++++++++++++++++++++++++++++++++++++++++++")
		if accountUpdate(accountObj) {
			return ""
		} else {
			return error.AddError("UpdateAccount account package", "Check your path or object to Update AccountStruct", "logical error")

		}
		fmt.Println("iam update")
	}
	return error.AddError("FindjsonFile account package", "Can't find the account obj "+accountObj.AccountPublicKey, "hack error")

}

/*----------------- function to validate the account before register  -----------------*/
func validateAccount(accountObj AccountStruct) bool {
	if len(accountObj.AccountName) < 8 || len(accountObj.AccountName) > 30 || (len(accountObj.AccountPassword) != 64) || len(accountObj.AccountAddress) < 5 || len(accountObj.AccountAddress) > 100 {
		fmt.Println("1")
		return false
	}

	re := regexp.MustCompile("^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$")
	if !re.MatchString(accountObj.AccountEmail) && accountObj.AccountEmail != "" {
		fmt.Println("2")
		return false
	}
	return true
}

/////////////////*******func Add by Aya to get publickey using Any string ----

func getPublicKeyUsingString(Key string) string {

	existingAccountUsingName := findAccountByAccountName(Key)

	existingAccountusingEmail := findAccountByAccountEmail(Key)
	existingAccountusingPhoneNumber := findAccountByAccountPhoneNumber(Key)
	if existingAccountUsingName.AccountPublicKey != "" {
		return existingAccountUsingName.AccountPublicKey
	}
	if existingAccountusingEmail.AccountPublicKey != "" {
		return existingAccountusingEmail.AccountPublicKey
	}
	if existingAccountusingPhoneNumber.AccountPublicKey != "" {
		return existingAccountusingPhoneNumber.AccountPublicKey
	}

	return ""

}

/*-------------FUNCTION TO CHECK Acoount----*/

func checkAccount(userAccountObj AccountStruct) string {

	existingAccountUsingName := findAccountByAccountName(userAccountObj.AccountName)
	existingAccountusingEmail := findAccountByAccountEmail(userAccountObj.AccountEmail)
	existingAccountusingPhoneNumber := findAccountByAccountPhoneNumber(userAccountObj.AccountPhoneNumber)

	if existingAccountUsingName.AccountPublicKey != "" && existingAccountUsingName.AccountPublicKey != userAccountObj.AccountPublicKey {

		return "UserName Found"
	}
	if existingAccountusingEmail.AccountPublicKey != "" && existingAccountusingEmail.AccountPublicKey != userAccountObj.AccountPublicKey && userAccountObj.AccountEmail != "" {
		fmt.Println("Email found", existingAccountusingEmail.AccountEmail, "  ", userAccountObj.AccountEmail)
		return "Email found"
	}
	if existingAccountusingPhoneNumber.AccountPublicKey != "" && existingAccountusingPhoneNumber.AccountPublicKey != userAccountObj.AccountPublicKey && userAccountObj.AccountPhoneNumber != "" {
		return "Phone Found "
	}
	return ""
}

/*-------------integrat account module with miner------*/
/*-------------check Befor Add------*/

func checkingIfAccountExixtsBeforeRegister(accountObj AccountStruct) string {

	/*if IfAccountExistsBefore(accountObj.AccountPublicKey) {
		return "public key exists before"
	}*/
	Error := checkAccount(accountObj)
	if Error != "" {
		return Error

	}

	if !validateAccount(accountObj) {
		return "please, check your data"
	}
	return ""

}
func checkingIfAccountExixtsBeforeAdd(accountObj AccountStruct) string {

	//IfAccountExistsBefore(accountObj.AccountPublicKey)
	if ifAccountExistsBefore(accountObj.AccountPublicKey) {
		return "the publick key exist before "
	}

	return ""

}

/*-------------check Befor update------*/
func checkingIfAccountExixtsBeforeUpdating(accountObj AccountStruct) string {
	if !(ifAccountExistsBefore(accountObj.AccountPublicKey)) {
		return "Please Check Your data to help me to find your account"
	}
	s := checkAccount(accountObj)
	if s != "" {
		return s
	}
	if !validateAccount(accountObj) {
		return "please, check your data"
	}
	return ""

}

/*-------------getAccountPassword-------*/
func getAccountPassword(AccountPublicKey string) string {
	return findAccountByAccountKey(AccountPublicKey).AccountPassword
}

/*-------------get AccountStruct using publicKey-------*/
// func getAccountByPublicKey(AccountPublicKey string) AccountStruct {
// 	return findAccountByAccountPublicKey(AccountPublicKey)
// }

// func GetAccountByPublicKey(AccountPublicKey string) AccountStruct {
// 	return findAccountByAccountPublicKey(AccountPublicKey)
// }

/*-------------get AccountStruct using email-------*/
func getAccountByEmail(AccountEmail string) AccountStruct {
	return findAccountByAccountEmail(AccountEmail)
}
func getAccountByPhone(AccountPhoneNumber string) AccountStruct {
	return findAccountByAccountPhoneNumber(AccountPhoneNumber)
}

/*-------------get AccountStruct using user name-------*/
func getAccountByName(AccountName string) AccountStruct {
	return findAccountByAccountName(AccountName)
}

/*-------------get AccountStruct using user name-------*/
func GetAccountByName(AccountName string) AccountStruct {
	return findAccountByAccountName(AccountName)
}

/*----------------AddBlockToAnaccount-----*/
func AddBlockToAccount(AccountPublicKey string, blockIndex string) {
	accountObj := findAccountByAccountPublicKey(AccountPublicKey)
	accountObj.BlocksLst = append(accountObj.BlocksLst, blockIndex)
	UpdateAccount2(accountObj)
}
func GetAccountByIndex(index string) AccountStruct {
	return findAccountByAccountKey(index)
}

func UpdateAccount2(accountObj AccountStruct) string {
	if (ifAccountExistsBefore(accountObj.AccountPublicKey)) && validateAccount(accountObj) {
		if accountUpdate2(accountObj) {
			return ""
		} else {
			return error.AddError("UpdateAccount account package", "Check your path or object to Update AccountStruct", "logical error")

		}
		fmt.Println("iam update22")
	}
	return error.AddError("FindjsonFile account package", "Can't find the account obj "+accountObj.AccountPublicKey, "hack error")

}

//SetPublicKey update the public key into the database
func SetPublicKey(accountObjc AccountStruct) {
	if addBKey(accountObjc) {
		fmt.Println("public key added successfully")
	} else {
		fmt.Println("failed to add public key")
	}
}
